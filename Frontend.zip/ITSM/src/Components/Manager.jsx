import React, { useState, useEffect } from 'react';
import axios from 'axios';
import { Accordion, AccordionSummary, InputAdornment, AccordionDetails, Typography, Card, CardContent, Avatar, TextField, Button, Box, Paper, InputLabel, Grid, IconButton, Divider, RadioGroup, FormControlLabel, Radio, FormLabel, FormControl, Dialog, DialogTitle, DialogContent, DialogActions } from '@mui/material';
import AddIcon from '@mui/icons-material/Add';
import ArrowDropDownIcon from '@mui/icons-material/ArrowDropDown';
import DeleteIcon from '@mui/icons-material/Delete';
import ArrowBackIcon from '@mui/icons-material/ArrowBack';
import { useNavigate, useParams } from 'react-router-dom';
import AccessTimeIcon from '@mui/icons-material/AccessTime';
import { SnackContext } from './GlobalComponents/SnackProvider';


const ManagerComponent = () => {
    const [images, setImages] = useState([]);
    const [incidentCategory, setincidentCategory] = useState('');
    const [incidentSubCategory, setincidentSubCategory] = useState('');
    const [incidentPriority, setincidentPriority] = useState('');
    const [incidentDescription, setincidentDescription] = useState('');
    const [role] = useState(localStorage.getItem('userRole'));
    const { caseId } = useParams();
    const navigate = useNavigate();
    const [actionRequired, setActionRequired] = useState('');
    const [assessmentDetails, setAssessmentDetails] = useState([]);
    const [recommendation, setRecommendation] = useState('');
    const { setSnack } = React.useContext(SnackContext);
    const [previewImage, setPreviewImage] = useState(null);
    const [open, setOpen] = useState(false);
    const [isDialogOpen, setIsDialogOpen] = useState(false);
    const [selectedManager, setSelectedManager] = useState(null);
    const [creationDate, setcreationDate] = useState('');
    const [creationTime, setcreationTime] = useState('');
    const [incidentDate, setincidentDate] = useState('');
    const [incidentTime, setincidentTime] = useState('');
    const [state, setstate] = useState('');
    const [city, setcity] = useState('');
    const [branch, setbranch] = useState('');
    const [department, setdepartment] = useState('');
    const [incidentType, setincidentType] = useState('');
    const [blockRoomNo, setblockRoomNo] = useState('');
    const [floor, setfloor] = useState('');
    const [patientId, setpatientId] = useState('');
    const [name, setname] = useState('');
    const [gender, setgender] = useState('');
    const [age, setage] = useState('');
    const [reportedBy, setreportedBy] = useState('');
    const [block, setblock] = useState('');
    const [roomNo, setroomNo] = useState('');
    const [status, setstatus] = useState('');
    const [correctiveActions, setCorrectiveActions] = useState('');
    const [preventiveActions, setPreventiveActions] = useState('');
  
    const [userRole, setUserRole] = useState('');
    const [finalReviewerComment, setfinalReviewerComment] = useState('');
    const [isExpanded1, setIsExpanded1] = useState(true);
    const [isExpanded2, setIsExpanded2] = useState(false);
    

    useEffect(() => {
        const userRole = localStorage.getItem('userRole');
        setUserRole(userRole || '');
    }, []);
    useEffect(() => {
        axios.get(`http://localhost:8989/getIncidentCaseById?caseId=${caseId}`)
            .then(response => {
                const { incidentType, roomNo,correctiveActions, floor, block,status, reportedBy, blockRoomNo, patientDetails, state, city, department, incidentDescription, branch, creationDate, creationTime, incidentDate, incidentTime, assesmentDetails, incidentCategory, incidentSubCategory, incidentPriority, attachments } = response.data;

                setreportedBy(reportedBy);
                setCorrectiveActions(correctiveActions);
                setincidentCategory(incidentCategory);
                setincidentSubCategory(incidentSubCategory);
                setbranch(branch);
                setdepartment(department);
                setblockRoomNo(blockRoomNo);
                setfloor(floor);
                setblock(block);
                setstatus(status);
                setroomNo(roomNo);
                setAssessmentDetails(response.data.assesmentDetails);
                setcreationDate(creationDate);
                setincidentType(incidentType);
                setcreationTime(creationTime);
                setincidentDate(incidentDate);
                setincidentTime(incidentTime);
                setincidentDescription(incidentDescription);
                setincidentPriority(incidentPriority);
                setstate(state);
                setcity(city);
                setpatientId(patientDetails.patientId);
                setname(patientDetails.name);
                setgender(patientDetails.gender);
                setage(patientDetails.age);
               
                
                // setImages(attachments.map(attachment => `data:image/png;base64,${attachment}`));
            })
            .catch(error => {
                console.error('Error fetching incident case details:', error);
            });
    }, [caseId]);

    const handleFinalReviewSubmit = async () => {
        const payload = {
            caseId: caseId,
            finalReviewerComment,
            
        };

        try {
            const response = await axios.post(`http://localhost:8989/investigationFindings/${caseId}`, payload);
            if (response?.status === 200) {
                setSnack({
                    open: true,
                    message: `The case has been successfully completed`,
                    severity: "success",

                });
                navigate("/dashboard");
            } else {
                console.error("Unexpected response:", response);
                setSnack('Failed to submit final review. Please try again.');
            }
        } catch (error) {
            console.error("Error submitting review:", error);
            setSnack("There was an error processing your request. Please try again later.");
        }
    };

    const handleAccordionChange1 = (event, expanded) => {
        setIsExpanded1(expanded);
    };
    const handleAccordionChange2 = (event, expanded) => {
        setIsExpanded2(expanded);
    };

    // const closeDialog = () => {
    //     setIsDialogOpen(false);
    //     setSelectedManager(null);
    // };

    // const handleClose = () => {
    //     setIsDialogOpen(false);
    //     setOpen(false);
    //     setPreviewImage(null);

    // };
    // const handleSubmit = () => {
    //     const data = {
    //         caseId: caseId,
    //         incidentInstructor: role,
    //         incidentManager: 'paivi@aaseya.com',
    //         actionRequired: actionRequired.toLowerCase(),
    //     };

    //     axios.post('http://localhost:8989/submitReviewByInstructor', data)
    //         .then(response => {
    //             const businessKey = response?.data?.businessKey; // Assuming the businessKey is in the response
    //             setSnack({
    //                 open: true,
    //                 message: `${caseId} has been successfully moved for final review `,
    //                 severity: 'success'
    //             });

    //             navigate('/dashboard'); // Navigate to the dashboard
    //         })
    //         .catch(error => {
    //             console.error('Error submitting case:', error);
    //             setSnack({
    //                 open: true, // Ensure open is set to true for the snack
    //                 message: 'Failed to submit case. Please try again.',
    //                 severity: 'error'
    //             });
    //         });
    // };
    // Handle image upload
    // const handleImageUpload = (event) => {
    //     const uploadedImages = Array.from(event.target.files).map((file) => URL.createObjectURL(file));
    //     setImages((prevImages) => [...prevImages, ...uploadedImages]);
    // };

    // // Handle image click (view the image)
    // const handleImageClick = (image) => {
    //     // Handle image preview or any other functionality you want to implement
    // };

    // // Handle image remove
    // const handleImageRemove = (index) => {
    //     setImages((prevImages) => prevImages.filter((_, i) => i !== index));
    // };

    return (
        <Box sx={{ display: 'flex', justifyContent: 'center', alignItems: 'center', backgroundColor: '#f4f4f4', padding: '10px', paddingTop: "10px", height: "90vh" }}>
            <Paper elevation={10} sx={{ width: '95%', padding: '15px', backgroundColor: '#DEECF1', borderRadius: '8px', height: "95%", display: 'flex', flexDirection: 'column' }}>
                <Box mb={-4} display="flex" alignItems="center">
                    <IconButton onClick={() => navigate('/dashboard')}>
                        <ArrowBackIcon sx={{ cursor: 'pointer', mr: -2 }} />
                    </IconButton>
                    <Button variant="text" sx={{ color: 'black', fontWeight: 'bold' }} onClick={() => navigate('/dashboard')}>
                        <Typography variant="h7" fontWeight='bold'>back</Typography>
                    </Button>
                </Box>
                <h2></h2>
                <Box sx={{ flex: 1, display: 'flex', flexDirection: 'column', overflowY: 'auto' }}>
                    <Paper elevation={8} sx={{ padding: '10px', paddingTop: "15px", backgroundColor: 'white', borderRadius: '8px', flex: 1 }}>
                        <Accordion elevation={4} expanded={isExpanded1} onChange={handleAccordionChange1} sx={{ backgroundColor: '#DEECF1', borderRadius: '8px', }}>
                            <AccordionSummary expandIcon={<ArrowDropDownIcon fontSize="large" />} sx={{ backgroundColor: '#DEECF1', height: "50px", paddingTop: "10px", paddingLeft: "25px", borderColor: "black", borderRadius: "200px" }}>
                                <Typography variant="h6" fontWeight='bold'>Case Details</Typography>
                            </AccordionSummary>
                            <AccordionDetails sx={{ backgroundColor: 'white', }}>
                                <Grid container spacing={3}>
                                    <Grid item xs={12} sm={6} md={4} mt={1}>
                                        Creation Date
                                        <TextField fullWidth value={creationDate ? `${creationDate.split('-')[2]}-${creationDate.split('-')[1]}-${creationDate.split('-')[0]}`
                                            : ''} InputProps={{
                                                readOnly: true, endAdornment: (
                                                    <InputAdornment position="end">
                                                        <Typography sx={{ color: 'gray' }}>dd-mm-yyyy</Typography>
                                                    </InputAdornment>
                                                ),
                                            }} />
                                    </Grid>
                                    <Grid item xs={12} sm={6} md={4} mt={1}>
                                        Creation Time
                                        <TextField fullWidth variant="outlined" value={creationTime} InputProps={{
                                            readOnly: true, endAdornment: (
                                                <span style={{ display: 'flex', alignItems: 'center', marginRight: '8px', color: "gray" }}>
                                                    <AccessTimeIcon />
                                                </span>
                                            )
                                        }} />
                                    </Grid>
                                    <Grid item xs={12} sm={6} md={4} mt={1}>
                                        Incident Date
                                        <TextField fullWidth value={incidentDate ? `${incidentDate.split('-')[2]}-${incidentDate.split('-')[1]}-${incidentDate.split('-')[0]}`
                                            : ''} InputProps={{
                                                readOnly: true, endAdornment: (
                                                    <InputAdornment position="end">
                                                        <Typography sx={{ color: 'gray' }}>dd-mm-yyyy</Typography>
                                                    </InputAdornment>
                                                ),
                                            }} />
                                    </Grid>
                                    <Grid item xs={12} sm={6} md={4} mt={1}>
                                        Incident Time
                                        <TextField fullWidth variant="outlined" value={incidentTime} InputProps={{
                                            readOnly: true, endAdornment: (
                                                <span style={{ display: 'flex', alignItems: 'center', marginRight: '8px', color: "gray" }}>
                                                    <AccessTimeIcon />
                                                </span>
                                            )
                                        }} />
                                    </Grid>

                                    <Grid item xs={12} mt={1} mb={-2}>
                                        <Typography variant="h6" fontWeight='bold'>Incident Details</Typography>
                                    </Grid>
                                    <Grid item xs={12} sm={6} md={4} mt={1}>
                                        Incident Type
                                        <TextField fullWidth variant="outlined" value={incidentType} InputProps={{ readOnly: true }}
                                        />
                                    </Grid>
                                    <Grid item xs={12} sm={6} md={4} mt={1}>
                                        Incident Category
                                        <TextField fullWidth variant="outlined" value={incidentCategory} InputProps={{ readOnly: true }} />
                                    </Grid>

                                    <Grid item xs={12} sm={6} md={4} mt={1}>
                                        Incident Sub Category
                                        <TextField fullWidth variant="outlined" value={incidentSubCategory} InputProps={{ readOnly: true }} />
                                    </Grid>

                                    {/* <Grid item xs={12} sm={6} md={4} mt={1}>
                                        Incident Priority
                                        <TextField fullWidth variant="outlined" value={incidentPriority} InputProps={{ readOnly: true }} />
                                    </Grid> */}
                                    <Grid item xs={12} sm={8} md={6} mt={1}>
                                        Incident Description
                                        <TextField fullWidth variant="outlined" value={incidentDescription} InputProps={{ readOnly: true }} />
                                    </Grid>
                                    <Grid item xs={12} mt={1} mb={-2}>
                                        {/* <Divider style={{ backgroundColor: 'black', margin: '10px' }} /> */}
                                        <Typography variant="h6" fontWeight='bold'>Location Details</Typography>
                                    </Grid>
                                    <Grid item xs={12} sm={6} md={4} mt={1}>
                                        Room no.
                                        <TextField fullWidth variant="outlined" value={roomNo} InputProps={{ readOnly: true }} />
                                    </Grid>
                                    <Grid item xs={12} sm={6} md={4} mt={1}>
                                        Block
                                        <TextField fullWidth variant="outlined" value={block} InputProps={{ readOnly: true }} />
                                    </Grid>
                                    <Grid item xs={12} sm={6} md={4} mt={1}>
                                        Floor
                                        <TextField fullWidth variant="outlined" value={floor} InputProps={{ readOnly: true }} />
                                    </Grid>
                                    <Grid item xs={12} sm={6} md={4} mt={1}>
                                        Department
                                        <TextField fullWidth variant="outlined" value={department} InputProps={{ readOnly: true }} />
                                    </Grid>
                                    <Grid item xs={12} sm={6} md={4} mt={1}>
                                        Branch
                                        <TextField fullWidth variant="outlined" value={branch} InputProps={{ readOnly: true }} />
                                    </Grid>

                                    <Grid item xs={12} sm={6} md={4} mt={1}>
                                        State
                                        <TextField fullWidth variant="outlined" value={state} InputProps={{ readOnly: true }} />
                                    </Grid>
                                    <Grid item xs={12} sm={6} md={4} mt={1}>
                                        City
                                        <TextField fullWidth variant="outlined" value={city} InputProps={{ readOnly: true }} />
                                    </Grid>
                                    <Grid item xs={12} mt={1} mb={-2}>
                                        <Typography variant="h6" fontWeight='bold'>Patient Details</Typography>
                                    </Grid>

                                    <Grid item xs={12} sm={6} md={4} mt={1}>
                                        Patient ID
                                        <TextField fullWidth variant="outlined" value={patientId} InputProps={{ readOnly: true }} />
                                    </Grid>
                                    <Grid item xs={12} sm={6} md={4} mt={1}>
                                        Patient Name
                                        <TextField fullWidth variant="outlined" value={name} InputProps={{ readOnly: true }} />
                                    </Grid>
                                    <Grid item xs={12} sm={6} md={4} mt={1}>
                                        Patient Age
                                        <TextField fullWidth variant="outlined" value={age} InputProps={{ readOnly: true }} />
                                    </Grid>
                                    <Grid item xs={12} sm={6} md={4} mt={1}>
                                        Patient Gender
                                        <TextField fullWidth variant="outlined" value={gender} InputProps={{ readOnly: true }} />
                                    </Grid>
                                    <Grid item xs={12} sm={6} md={4} mt={1}>
                                        Staff Involved Name
                                        <TextField fullWidth variant="outlined" value={reportedBy} InputProps={{ readOnly: true }} />
                                    </Grid>
                                    <Grid item xs={12} sm={6} md={4} mt={1}>
                                        Staff Role
                                        <TextField fullWidth variant="outlined" value={role} InputProps={{ readOnly: true }} />
                                    </Grid>
                                </Grid>
                                {/* <Grid item xs={12}>

                                    { <Divider style={{ backgroundColor: 'black', margin: '10px' }} /> }
                                    <Typography variant="h6" fontWeight='bold'>Attachments</Typography>

                                    <InputLabel variant="h6" sx={{ fontWeight: 'bold' }}></InputLabel>
                                    <Button
                                        variant="outlined"
                                        component="label"
                                        startIcon={<AddIcon />}
                                        sx={{
                                            color: 'black',
                                            borderColor: 'black',
                                            textTransform: 'none',
                                            '&:hover': {
                                                borderColor: 'black',
                                                backgroundColor: 'rgba(0, 0, 0, 0.1)',
                                            },
                                        }}
                                    >
                                        Attach Evidence
                                        <input type="file" accept="image/*" hidden multiple onChange={handleImageUpload} />
                                    </Button>
                                    <Box mt={2} display="flex" flexWrap="wrap" gap={2}>
                                        {images.map((image, index) => (
                                            <Box key={index} sx={{ position: 'relative', width: '100px', height: '100px' }}>
                                                <img src={image} alt={`attachment-${index}`} style={{ width: '100%', height: '100%', objectFit: 'cover' }} onClick={() => handleImageClick(image)} />
                                                <IconButton
                                                    onClick={() => handleImageRemove(index)}
                                                    sx={{ position: 'absolute', top: 0, right: 0, color: 'red' }}
                                                >
                                                    <DeleteIcon />
                                                </IconButton>
                                            </Box>
                                        ))}
                                    </Box>
                                </Grid> */}
                            </AccordionDetails>
                        </Accordion>
                        <Grid item xs={12} mt={2}>
                        </Grid>
                        <Accordion elevation={2} expanded={isExpanded2} onChange={handleAccordionChange2} sx={{ backgroundColor: '#DEECF1', }}>
                            <AccordionSummary expandIcon={<ArrowDropDownIcon fontSize="large" />} sx={{ height: "50px", paddingTop: "10px", paddingLeft: "25px", borderColor: "black" }}>
                                <Typography variant="h6" fontWeight='bold'>Patient Assessment</Typography>
                            </AccordionSummary>
                            {assessmentDetails.map((assessment, index) => (
                                 <AccordionDetails key={index} sx={{ backgroundColor: 'white' }}>
                                    <Typography variant="h6" fontWeight='bold' mt={2} >
                                        {assessment.assessmentType} Assessment 
                                    </Typography>
                                    <Grid container spacing={2}>
                                        <Grid item xs={12} sm={6} md={4} mt={1}>
                                            Blood Pressure
                                            <TextField fullWidth variant="outlined" value={assessment.bloodPressure}
                                                InputProps={{
                                                    readOnly: true, endAdornment: (
                                                        <InputAdornment position="end">
                                                            <Typography sx={{ color: 'gray' }}>mmHG</Typography>
                                                        </InputAdornment>
                                                    ),
                                                }} />
                                        </Grid>
                                        <Grid item xs={12} sm={6} md={4} mt={1}>
                                            Heart Rate
                                            <TextField fullWidth variant="outlined" value={assessment.heartRate}
                                                InputProps={{
                                                    readOnly: true, endAdornment: (
                                                        <InputAdornment position="end">
                                                            <Typography sx={{ color: 'gray' }}>BPM</Typography>
                                                        </InputAdornment>
                                                    ),
                                                }} />
                                        </Grid>
                                        <Grid item xs={12} sm={6} md={4} mt={1}>
                                            Temperature
                                            <TextField fullWidth variant="outlined" value={assessment.temperature}
                                                InputProps={{
                                                    readOnly: true, endAdornment: (
                                                        <InputAdornment position="end">
                                                            <Typography sx={{ color: 'gray' }}>'C</Typography>
                                                        </InputAdornment>
                                                    ),
                                                }} />
                                        </Grid>
                                        <Grid item xs={12} sm={6} md={4} mt={1}>
                                            Respiratory Rate
                                            <TextField fullWidth variant="outlined" value={assessment.respiratoryRate}
                                                InputProps={{
                                                    readOnly: true,
                                                    endAdornment: (
                                                        <InputAdornment position="end">
                                                            <Typography sx={{ color: 'gray' }}>breaths per minute</Typography>
                                                        </InputAdornment>
                                                    ),
                                                }} />
                                        </Grid>
                                        <Grid item xs={12} sm={6} md={4} mt={1}>
                                            Oxygen Saturation
                                            <TextField fullWidth variant="outlined" value={assessment.oxygenSaturation}
                                                InputProps={{
                                                    readOnly: true,
                                                    endAdornment: (
                                                        <InputAdornment position="end">
                                                            <Typography sx={{ color: 'gray' }}>%</Typography>
                                                        </InputAdornment>
                                                    ),
                                                }} />
                                        </Grid>
                                        {/* <Grid item xs={12} sm={6} md={4} mt={1}>
                                            Level of Consciousness
                                            <TextField fullWidth variant="outlined" value={assessment.levelOfConsciousnes} InputProps={{ readOnly: true }} />
                                        </Grid> */}
                                        <Grid item xs={12} sm={6} md={4} mt={1}>
                                            Pain Level
                                            <TextField fullWidth variant="outlined" value={assessment.painLevel} InputProps={{ readOnly: true }} />
                                        </Grid>
                                        <Grid item xs={12} sm={6} md={4} mt={1}>
                                            Mental Status
                                            <TextField fullWidth variant="outlined" value={assessment.mentalStatus} InputProps={{ readOnly: true }} />
                                        </Grid>
                                        <Grid item xs={12} sm={6} md={4} mt={1}>
                                            Mobility Status
                                            <TextField fullWidth variant="outlined" value={assessment.mobilityStatus} InputProps={{ readOnly: true }} />
                                        </Grid>
                                        <Grid item xs={12} sm={6} md={4} mt={1}>
                                            Injuries Sustained
                                            <TextField fullWidth variant="outlined" value={assessment.injuriesSustained} InputProps={{ readOnly: true }} />
                                        </Grid>
                                        <Grid item xs={12} sm={6} md={4} mt={1}>
                                            Patient Condition
                                            <TextField fullWidth variant="outlined" value={assessment.patientStatus} InputProps={{ readOnly: true }} />
                                        </Grid>
                                        <Grid item xs={12} sm={8} md={6} mt={1}>
                                            Incident Description
                                            <TextField fullWidth variant="outlined" value={assessment.description} InputProps={{ readOnly: true }} />
                                        </Grid>
                                    </Grid>
                                </AccordionDetails>
                            ))}
                        </Accordion>
                        <Grid item xs={12}>
                            {/* <Divider style={{ backgroundColor: 'black', margin: '10px' }} /> */}
                        </Grid>

                        <Grid container spacing={1}>

                            {/* <Grid item xs={4}>
                                <FormControl component="fieldset" style={{ width: '50%', paddingTop: '5px', paddingLeft: "30px" }}>
                                    <FormLabel component="legend" color="black" style={{ fontWeight: 'bold', paddingTop: '10px' }}>
                                        Action Required
                                    </FormLabel>
                                    <RadioGroup value={actionRequired} onChange={handleActionRequiredChange}>
                                        <FormControlLabel
                                            value="Yes"
                                            control={<Radio style={{ color: 'black' }} />}
                                            label="Yes"
                                            style={{ border: '1px solid #E0E0E0', borderRadius: '8px', padding: '4px', marginBottom: '8px' }}
                                        />
                                        <FormControlLabel
                                            value="No"
                                            control={<Radio style={{ color: 'black' }} />}
                                            label="No"
                                            style={{ border: '1px solid #E0E0E0', borderRadius: '8px', padding: '4px' }}
                                        />
                                    </RadioGroup>
                                </FormControl>
                            </Grid> */}
                            {/* <Grid item xs={4}>
    <FormControl component="fieldset" style={{ width: '50%', paddingTop: '5px', paddingLeft: "30px" }}>
        <FormLabel component="legend" color="black" style={{ fontWeight: 'bold', paddingTop: '10px' }}>
            Action Required
        </FormLabel>
        <RadioGroup value={actionRequired} onChange={handleActionRequiredChange}>
            <FormControlLabel
                value="Yes"
                control={<Radio style={{ color: 'black' }} disabled />} 
                label="Yes"
                style={{ border: '1px solid #E0E0E0', borderRadius: '8px', padding: '4px', marginBottom: '8px' }}
            />
            <FormControlLabel
                value="No"
                control={<Radio style={{ color: 'black' }}  />} 
                label="No"
                style={{ border: '1px solid #E0E0E0', borderRadius: '8px', padding: '4px' }}
            />
        </RadioGroup>
    </FormControl>
</Grid> */}

                            <Grid container spacing={3} sx={{ paddingTop: "20px", paddingLeft: "8px" }}>
                                <Grid item xs={12} sm={6}>
                                    <InputLabel sx={{ fontWeight: 'bold' }}>Corrective Actions Required</InputLabel>
                                    <TextField value={correctiveActions} InputProps={{ readOnly: true }} fullWidth variant="outlined" />
                                </Grid>
                                {/* {actionRequired === 'Yes' && (
        <Grid item xs={12} sm={6}>
            <InputLabel sx={{ fontWeight: 'bold' }}>Preventive Actions Required</InputLabel>
            <TextField fullWidth variant="outlined" value={recommendation} InputProps={{ readOnly: true }} />
        </Grid>
    )} */}
                            </Grid>
                            <Grid item xs={12}>
                                {/* <Divider style={{ backgroundColor: 'black', margin: '10px' }} /> */}
                            </Grid>

                            <Grid item xs={10}>
                                <InputLabel sx={{ fontWeight: 'bold' }}>Comments</InputLabel>
                                <TextField
                                    value={finalReviewerComment} onChange={(e) => setfinalReviewerComment(e.target.value)} fullWidth variant="outlined" multiline rows={2} InputProps={{
                                        readOnly: role === 'nurse' || role === 'doctor'}}
                                />
                            </Grid>

                            <>
                                {/* <Typography variant="h6">Choose Manager</Typography>
    <Grid container spacing={3}>
        {Managers.map((Manager, index) => (
            <Grid item xs={12} sm={6} md={3} key={index}>
                <Card
                    sx={{ display: 'flex', alignItems: 'center', cursor: 'pointer' }}
                    onClick={() => handleClickOpen(Manager)}
                >
                    <Avatar alt={Manager.name} src={Manager.image} sx={{ margin: 2, width: 56, height: 56 }} />
                    <CardContent>
                        <Typography variant="h6" fontWeight="bold">
                            {Manager.name}
                        </Typography>
                        <Typography>{Manager.specialist}</Typography>
                        <Typography>{Manager.experience}</Typography>
                    </CardContent>
                </Card>
            </Grid>
        ))}
    </Grid> */}
                                {/* <Dialog open={isDialogOpen} onClose={closeDialog}>
        <DialogTitle>Manager Details</DialogTitle>
        {selectedManager && (
            <DialogContent>
                <Avatar alt={selectedManager.name} src={selectedManager.image} sx={{ width: 100, height: 100, margin: 'auto' }} />
                <Typography variant="h6" align="center" fontWeight="bold">
                    {selectedManager.name}
                </Typography>
                <Typography align="center">{selectedManager.specialist}</Typography>
                <Typography align="center">{selectedManager.experience}</Typography>
                <Button onClick={closeDialog} color="primary" variant="contained" fullWidth sx={{ marginTop: 2 }}>
                    Close
                </Button>
            </DialogContent>
        )}
    </Dialog> */}
                            </>

                        </Grid>
                        <Box sx={{ mt: (isExpanded1 || isExpanded2) ? 2 : 30, ml: 205, }} >
                            <Button width="10vw" variant="contained" onClick={handleFinalReviewSubmit}
                                sx={{
                                    backgroundColor: '#4D99BD', color: 'white', textTransform: 'none', borderRadius: 2,
                                    "&:hover": { backgroundColor: "#145A7B", color: "White", },
                                    "&:focus": { outline: 'none', boxShadow: 'none', }
                                }} >
                                Submit
                            </Button>
                        </Box>
                    </Paper>
                </Box>
            </Paper>
            {/* <Dialog open={open} onClose={handleClose} maxWidth="md" fullWidth>
                <DialogTitle>Image Preview</DialogTitle>
                <DialogContent>
                    {previewImage && (
                        <img src={previewImage} alt="Preview" style={{ width: '100%', height: '100%', objectFit: 'contain' }} />
                    )}
                </DialogContent>
                <DialogActions>
                    <Button onClick={handleClose} color="black">Close</Button>
                </DialogActions>
            </Dialog> */}
        </Box>
    );
};
export default ManagerComponent;
