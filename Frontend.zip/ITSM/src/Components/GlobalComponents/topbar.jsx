import React from 'react';
import AppBar from '@mui/material/AppBar';
import Toolbar from '@mui/material/Toolbar';
import Typography from '@mui/material/Typography';
import Image from '../../assets/logoFull.png'; 

const TopBar = () => {
  return (
    <AppBar position="static" style={{ backgroundColor: '#145A7B', color: '#145A7B' }}>
      <Toolbar>
        <img src={Image} alt="Logo" style={{ height: "5vh" }} />
        
        <Typography variant="h6" sx={{ flexGrow: 1, marginLeft: '10px', fontWeight: 'bold',color: 'white' }}>
             HEALTHCARE IT SERVICE MANAGEMENT
        </Typography>
      </Toolbar>
    </AppBar>
  );
};

export default TopBar;
