import React, { useState } from 'react';
import { Drawer, List, ListItem, ListItemIcon, ListItemText, styled, Box } from '@mui/material';
import DashboardIcon from '@mui/icons-material/Dashboard';
import AnalyticsIcon from '@mui/icons-material/Analytics';
import NotificationsIcon from '@mui/icons-material/Notifications';
import LogoutIcon from '@mui/icons-material/Logout';
import { useNavigate } from 'react-router-dom';
import { useTheme } from '@mui/material/styles';

const DrawerStyled = styled(Drawer)(({ theme, open }) => ({
  width: open ? 200 : 40,
  display: 'flex',
  flexShrink: 0,
  whiteSpace: 'nowrap',
  boxSizing: 'border-box',
  color: 'black',
  height: 'calc(100vh - 8vh)',
  marginTop: 'calc(7vh)',
  transition: theme.transitions.create('width', {
    easing: theme.transitions.easing.sharp,
    duration: theme.transitions.duration.enteringScreen,
  }),
  '& .MuiDrawer-paper': {
    width: open ? 240 : 60,
    transition: theme.transitions.create('width', {
      easing: theme.transitions.easing.sharp,
      duration: theme.transitions.duration.leavingScreen,
    }),
    overflowX: 'hidden',
    backgroundColor: '#4D99BD',
    height: 'calc(100vh - 4vh)',
    marginTop: 'calc(7vh)',
   
  },
}));

const Sidebar = ({ setUser }) => {
  const [isSidebarOpen, setIsSidebarOpen] = useState(false);
  const navigate = useNavigate();
  const theme = useTheme();

  const handleDashboardClick = () => {
    navigate('/dashboard');
  };

  const handleLogout = () => {
    localStorage.clear();
    setUser({});
    navigate('/');
  };

  return (
    <DrawerStyled
      variant="permanent"
      open={isSidebarOpen}
      onMouseEnter={() => setIsSidebarOpen(true)}
      onMouseLeave={() => setIsSidebarOpen(false)}
    >
      <List sx={{ display: 'flex', flexDirection: 'column', padding: 0 }}>
        <ListItem  button onClick={handleDashboardClick}
         sx={{ justifyContent: isSidebarOpen ? 'flex-start' : 'center',  padding: '15px', paddingTop:"20px", borderRadius: '8px', backgroundColor: '#4D99BD', margin: '5px 0', }}
        >
          <ListItemIcon
            sx={{ color: '#FFFFFF',  paddingLeft: isSidebarOpen ? "30px" : "15px",  }}
          >
            <DashboardIcon />
          </ListItemIcon>
          {isSidebarOpen && (
            <ListItemText
              primary="Dashboard" sx={{ color: '#FFFFFF', transition: 'opacity 0.3s', opacity: 1, marginLeft: '2px' }}
            />
          )}
        </ListItem>
        <ListItem  button onClick={handleDashboardClick}
         sx={{ justifyContent: isSidebarOpen ? 'flex-start' : 'center',  padding: '15px', paddingTop:"0px", borderRadius: '8px', backgroundColor: '#4D99BD', margin: '5px 0',}}
        >
          <ListItemIcon
            sx={{ color: '#FFFFFF',  paddingLeft: isSidebarOpen ? "30px" : "15px",  }}
          >
            <AnalyticsIcon />
          </ListItemIcon>
          {isSidebarOpen && (
            <ListItemText
              primary="Analytics" sx={{ color: '#FFFFFF', transition: 'opacity 0.3s', opacity: 1, marginLeft: '2px' }}
            />
          )}
        </ListItem>
        <ListItem  button onClick={handleDashboardClick}
         sx={{ justifyContent: isSidebarOpen ? 'flex-start' : 'center',  padding: '15px', paddingTop:"0px", borderRadius: '8px', backgroundColor: '#4D99BD', margin: '5px 0' }}
        >
          <ListItemIcon
            sx={{ color: '#FFFFFF',  paddingLeft: isSidebarOpen ? "30px" : "15px",  }}
          >
            <NotificationsIcon />
          </ListItemIcon>
          {isSidebarOpen && (
            <ListItemText
              primary="Notifications" sx={{ color: '#FFFFFF', transition: 'opacity 0.3s', opacity: 1, marginLeft: '2px' }}
            />
          )}
        </ListItem>
        
        {/* <Box sx={{ flexGrow: 10 }} /> */}

        <ListItem button onClick={handleLogout}
          sx={{ color: '#FFFFFF',  padding: '15px',  display: 'flex',
            justifyContent: isSidebarOpen ? 'flex-start' : 'center',
            backgroundColor: '#4D99BD', borderRadius: '8px',  position: 'fixed', bottom: 60,  width: isSidebarOpen ? 240 : 60, margin: '2px 0', transition: theme.transitions.create('width', {
              easing: theme.transitions.easing.sharp,
              duration: theme.transitions.duration.enteringScreen,
            }), }}
        >
          <ListItemIcon
            sx={{ color: '#FFFFFF',  paddingLeft: isSidebarOpen ? "30px" : "15px",  transition: theme.transitions.create('width', {
              easing: theme.transitions.easing.sharp,
              duration: theme.transitions.duration.enteringScreen,
            }), }}
          >
            <LogoutIcon sx={{ marginTop: "8px" }} />
          </ListItemIcon>
          {isSidebarOpen && (
            <ListItemText primary="Logout" sx={{ color: '#FFFFFF', marginLeft: '2px',  transition: theme.transitions.create('width', {
              easing: theme.transitions.easing.sharp,
              duration: theme.transitions.duration.enteringScreen,
            }), }}
            />
          )}
        </ListItem>
      </List>
    </DrawerStyled>
  );
};

export default Sidebar;
