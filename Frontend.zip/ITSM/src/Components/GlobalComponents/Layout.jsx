import { Box } from "@mui/material";
import React, { useState } from "react";
import { Outlet } from "react-router-dom";
import TopBar from "./topbar";
import Sidebar from "./sidebar"; 

const Layout = ({ user, setUser }) => {
  const [isSidebarOpen, setIsSidebarOpen] = useState(false);
  return (
    <Box sx={{ width: "100vw", height: "100vh", overflow: "hidden" }}>
  <Box
    sx={{
      width: "100vw",
      position: "fixed",
      height: "5vh",
      zIndex: 9,
    }}
  >
    <TopBar />
  </Box>
  
  <Box sx={{ display: "flex", height: "100%", mt: "5vh" }}>
  <Sidebar setUser={setUser} isSidebarOpen={isSidebarOpen} setIsSidebarOpen={setIsSidebarOpen} />
    <Box sx={{ width: isSidebarOpen ? "240px" : "60px", position: "fixed", height: "calc(100vh - 5vh)", top: "5vh", zIndex: 8, transition: "width 0.3s ease", }}
    >    
    </Box>    
    <Box
      sx={{
        flexGrow: 1,
        ml: isSidebarOpen ? "200px" : "0px", // Adjusts based on sidebar state
        mt: "2vh", // Offset to avoid overlapping TopBar
        overflowY: "auto",
        p: "0px", // Consistent padding on all sides
        height: "calc(100vh - 5vh)", // Full height minus TopBar height
        boxSizing: "border-box", // Ensures padding fits within width/height
        transition: "margin-left 0.3s ease", // Smooth transition for Outlet adjustment
      }}
    >
      <Outlet />
    </Box>
  </Box>
</Box>

  );
};

export default Layout;
