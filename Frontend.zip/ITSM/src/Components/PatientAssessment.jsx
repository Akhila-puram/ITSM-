import React, { useState, useEffect } from 'react';
import { Accordion, AccordionSummary, AccordionDetails, Typography, InputAdornment, Box, Select, styled, Paper, TextField, FormControl, Button, Grid, IconButton, Dialog, DialogTitle, DialogContent, DialogActions, RadioGroup, FormControlLabel, Radio } from '@mui/material';
import { useNavigate, useParams } from 'react-router-dom';
import DeleteIcon from '@mui/icons-material/Delete'; // Import DeleteIcon
import axios from 'axios';
import { SnackContext } from './GlobalComponents/SnackProvider';

const PatientAssessment = () => {
    const [images, setImages] = useState([]);
    const { caseId } = useParams();
    const [previewImage, setPreviewImage] = useState(null);
    const navigate = useNavigate();
    const [open, setOpen] = useState(false);
    const [status, setStatus] = useState('');
    const [assessmentType, setAssessmentType] = useState('');
    const [assessmentDate, setAssessmentDate] = useState(new Date().toISOString().split('T')[0]);
    const [bloodPressure, setBloodPressure] = useState('');
    const [heartRate, setHeartRate] = useState('');
    const [temperature, setTemperature] = useState('');
    const [respiratoryRate, setRespiratoryRate] = useState('');
    const [oxygenSaturation, setOxygenSaturation] = useState('');
    const [levelOfConsciousness, setLevelOfConsciousness] = useState('');
    const [painLevel, setPainLevel] = useState('');
    const [mentalStatus, setMentalStatus] = useState('');
    const [mobilityStatus, setMobilityStatus] = useState('');
    const [injuriesSustained, setInjuriesSustained] = useState('');
    const [medications, setMedications] = useState([]);
    const [description, setdescription] = useState('');
    const [patientStatus, setPatientStatus] = useState('');
    const [patientCondition, setPatientCondition] = useState('');
    const [medicationInput, setMedicationInput] = useState('');

    const { setSnack } = React.useContext(SnackContext);
    


    useEffect(() => {
        const status = localStorage.getItem('status');
        if (status) {
            setAssessmentType(status === 'open' ? 'Initial' : 'Followup');
        }
    }, []);
    console.log('status:', status);
    const handleImageUpload = (event) => {
        const files = Array.from(event.target.files);
        const newImages = files.map((file) => {
            const reader = new FileReader();
            return new Promise((resolve, reject) => {
                reader.onloadend = () => resolve(reader.result);
                reader.onerror = reject;
                reader.readAsDataURL(file);
            });
        });
        Promise.all(newImages).then((urls) => setImages((prevImages) => [...prevImages, ...urls]));
    };

    const handleImageRemove = (index) => {
        setImages((prevImages) => prevImages.filter((_, i) => i !== index));
    };
    const StyledButton = styled(Button)(({ theme }) => ({
        backgroundColor: "#4D99BD",
        padding: "8px 30px",
        textAlign: "center",
        color: "white",
        fontWeight: 600,
        fontSize: "0.8rem",
        borderRadius: "2em",
        border: "1px solid #145A7B",
        "&:hover": { backgroundColor: "#145A7B", color: "White", },
    }));

    const handleInputChange = (e) => {
        setMedicationInput(e.target.value);
    };


    const SecondaryButton = styled(Button)(({ theme }) => ({
        padding: "8px 30px",
        textAlign: "center",
        color: "#4D99BD",
        fontWeight: 600,
        fontSize: "0.8rem",
        borderRadius: "2em",
        border: "1px solid #145A7B",
        "&:hover": { backgroundColor: "#4D99BD", color: "White", },
    }));


    const handleImageClick = (image) => { setPreviewImage(image); setOpen(true); };
    const handleClose = () => { setOpen(false); setPreviewImage(null); };
    const handleBack = () => { navigate("/dashboard"); }
    const handleSave = () => { };

    const handleSubmit = async () => {
        const medicationsArray = medicationInput.split(',').map(med => med.trim()).filter(Boolean);
        const payload = {
            assessmentType, assessmentDate, bloodPressure, heartRate, temperature, respiratoryRate, oxygenSaturation, levelOfConsciousness,
            painLevel, mentalStatus, mobilityStatus, injuriesSustained, medications: medicationsArray, description, patientStatus, patientCondition, description
        };
        try {
            const response = await axios.post(`http://localhost:8989/savePatientAssessmentDetails/${caseId}`, payload);
            if (response.status === 200) {
                setSnack({
                    open: true,
                    message: 'Patient assessment details saved successfully!',
                    severity: 'success',
                });navigate("/dashboard");
            } else {
                setSnack({
                    open: true,
                    message: 'Failed to save patient assessment details.',
                    severity: 'error',
                });
            }
        } catch (error) {
            console.error('Error saving patient assessment details:', error);
            setSnack({
                open: true,
                message: 'An error occurred while saving patient assessment details. Please try again.',
                severity: 'error',
            });
        }
    };

    return (
        <Box>
            <Box mt={2} sx={{ display: 'flex', justifyContent: 'center', alignItems: 'center', marginRight: 6, }}>
                <Paper elevation={2} mt={2} sx={{ padding: '30px', backgroundColor: 'white', borderRadius: '8px', overflow: 'auto', width: "80%" }}>
                    <Typography variant="h4" sx={{ flexGrow: 1, paddingBottom: "20px" }}>
                        Patient Assessment
                    </Typography>
                    <Grid container spacing={3}>
                        <Grid item xs={12} sm={6} md={4} mt={2}>
                            Blood Pressure
                            <TextField
                                value={bloodPressure}
                                fullWidth
                                onChange={(e) => setBloodPressure(e.target.value)}
                                type="text"
                                sx={{ height: '30px', mb: 1 }}
                                InputProps={{
                                    endAdornment: (
                                        <InputAdornment position="end">
                                            <Typography sx={{ color: 'gray' }}>mmHg</Typography>
                                        </InputAdornment>
                                    ),
                                }}
                            />
                        </Grid>
                        <Grid item xs={12} sm={6} md={4} mt={2}>
                            Heart Rate
                            <TextField value={heartRate} onChange={(e) => setHeartRate(e.target.value)} fullWidth type="text" sx={{ height: '30px', mb: 1, }} InputProps={{
                                endAdornment: (
                                    <InputAdornment position="end">
                                        <Typography sx={{ color: 'gray' }}>BPM</Typography>
                                    </InputAdornment>
                                ),
                            }} />
                        </Grid>
                        <Grid item xs={12} sm={6} md={4} mt={2}>
                            Temperature
                            <TextField value={temperature} onChange={(e) => setTemperature(e.target.value)} fullWidth type="text" sx={{ height: '30px', mb: 1, }} InputProps={{
                                endAdornment: (
                                    <InputAdornment position="end">
                                        <Typography sx={{ color: 'gray' }}>°C</Typography>
                                    </InputAdornment>
                                ),
                            }} />
                        </Grid>
                        <Grid item xs={12} sm={6} md={4} mt={2}>
                            Respiratory Rate
                            <TextField value={respiratoryRate} onChange={(e) => setRespiratoryRate(e.target.value)} fullWidth type="text" sx={{ height: '30px', mb: 1, }} InputProps={{
                                endAdornment: (
                                    <InputAdornment position="end">
                                        <Typography sx={{ color: 'gray' }}>Breath per minute</Typography>
                                    </InputAdornment>
                                ),
                            }} />
                        </Grid>
                        <Grid item xs={12} sm={6} md={4} mt={2}>
                            Oxygen Saturation
                            <TextField value={oxygenSaturation} onChange={(e) => setOxygenSaturation(e.target.value)} fullWidth type="text" sx={{ height: '30px', mb: 1, }} InputProps={{
                                endAdornment: (
                                    <InputAdornment position="end">
                                        <Typography sx={{ color: 'gray' }}>%</Typography>
                                    </InputAdornment>
                                ),
                            }} />
                        </Grid>
                        <Grid item xs={12} sm={6} md={4} mt={2}>
                            Level of Consciousness
                            <TextField value={levelOfConsciousness} onChange={(e) => setLevelOfConsciousness(e.target.value)} fullWidth type="text" sx={{ height: '30px', mb: 1, }} InputProps={{ endAdornment: <span></span> }} />
                        </Grid>
                        <Grid item xs={12} sm={6} md={4} mt={2}>
                            Pain Level
                            <TextField value={painLevel} onChange={(e) => setPainLevel(e.target.value)} fullWidth type="text" sx={{ height: '30px', mb: 1, }} InputProps={{ endAdornment: <span></span> }} />
                        </Grid>
                        <Grid item xs={12} sm={6} md={4} mt={2}>
                            Mental Status
                            <TextField value={mentalStatus} onChange={(e) => setMentalStatus(e.target.value)} fullWidth type="text" sx={{ height: '30px', mb: 1, }} InputProps={{ endAdornment: <span></span> }} />
                        </Grid>
                        <Grid item xs={12} sm={6} md={4} mt={2}>
                            Mobility Status
                            <TextField value={mobilityStatus} onChange={(e) => setMobilityStatus(e.target.value)} fullWidth type="text" sx={{ height: '30px', mb: 1, }} InputProps={{ endAdornment: <span></span> }} />
                        </Grid>
                        <Grid item xs={12} sm={6} md={4} mt={2}>
                            Injuries Sustained
                            <TextField value={injuriesSustained} onChange={(e) => setInjuriesSustained(e.target.value)} fullWidth type="text" sx={{ height: '30px', mb: 1, }} InputProps={{ endAdornment: <span></span> }} />
                        </Grid>
                        <Grid item xs={12} sm={6} md={4} mt={2}>
                            <Typography>Medications (comma-separated)</Typography>
                            <TextField
                                value={medicationInput}
                                onChange={handleInputChange} // Handle input changes
                                fullWidth
                                 sx={{ mb: 1 }}
                            />
                            {/* <Typography variant="body2" color="textSecondary">
                                {medications.length > 0 ? `Total Medications: ${medications.length}` : 'No medications added.'}
                            </Typography> */}
                        </Grid>
                        <Grid item xs={12} sm={6} md={4} mt={2}>
                            Patient Condition
                            <TextField value={patientCondition} onChange={(e) => setPatientCondition(e.target.value)} fullWidth type="text" sx={{ height: '30px', mb: 1, }} InputProps={{ endAdornment: <span></span> }} />
                        </Grid>
                        <Grid item xs={12} sm={6} md={4} mt={2}>
                            Patient Status
                            <TextField value={patientStatus} onChange={(e) => setPatientStatus(e.target.value)} fullWidth type="text" sx={{ height: '30px', mb: 1, }} InputProps={{ endAdornment: <span></span> }} />
                        </Grid>
                        <Grid item xs={12} sm={6} md={6} mt={2}>
                            Incident Description
                            <TextField value={description} onChange={(e) => setdescription(e.target.value)} fullWidth multiline sx={{ height: '40px', mb: 1 }} />
                        </Grid>
                    </Grid>
                </Paper>
            </Box>
            <Grid container justifyContent="space-between" sx={{ pt: 4, px: 5 }}>
                <Grid item xs={6} sx={{ pl: 20 }}>
                    <SecondaryButton color="inherit" onClick={handleBack}> Back </SecondaryButton>
                </Grid>
                <Grid item xs={6} container columnGap={2} justifyContent="flex-end" sx={{ paddingRight: "200px" }}>
                    <SecondaryButton onClick={handleSave}> Save </SecondaryButton>
                    <StyledButton onClick={handleSubmit}>  Submit </StyledButton>
                </Grid>
            </Grid>
        </Box>
    );
};

export default PatientAssessment;
