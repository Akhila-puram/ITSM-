
// import React, { useEffect, useState } from 'react';
// import { Box, Grid, TextField, FormControl, Select, MenuItem, Paper, Typography, FormGroup, FormControlLabel, Checkbox } from '@mui/material';
// import { useNavigate } from 'react-router-dom';

// const IncidentDetails = () => {
//     const navigate = useNavigate();
//     const [fields, setFields] = useState([]);
//     const [incidentType, setIncidentType] = useState(localStorage.getItem('Incident Type') || '');
//     const [incidentCategory, setIncidentCategory] = useState(localStorage.getItem('Incident Category') || '');
//     const [incidentSubCategory, setIncidentSubCategory] = useState(localStorage.getItem('Incident Sub-category') || '');
//     const [incidentCategories, setIncidentCategories] = useState([]);
//     const [incidentSubCategories, setIncidentSubCategories] = useState([]);

//     const [selectedValues, setSelectedValues] = useState({});
//     const [businessid, setBusinessid] = useState("");

//     useEffect(() => {
//         const fetchedBusinessid = localStorage.getItem('businessid') || ""; 
//         setBusinessid(fetchedBusinessid); 

//         if (fetchedBusinessid) { 
//             fetch(`http://localhost:8989/getForms?formId=IncidentCreation&processDefinitionKey=${fetchedBusinessid}`)
//                 .then((response) => {
//                     if (!response.ok) {
//                         throw new Error('Network response was not ok');
//                     }
//                     return response.json();
//                 })
//                 .then((data) => {
//                     const schema = JSON.parse(data.schema);
//                     setFields(schema.components);
//                 })
//                 .catch((error) => console.error('Error fetching form data:', error));
//         }
//     }, []); // Run only once on mount

//     useEffect(() => {
//         // Re-fetch categories and subcategories if incidentType or incidentCategory are saved in localStorage
//         if (incidentType) {
//             fetch(`http://localhost:8989/incidentType?incidentType=${incidentType}`)
//                 .then((response) => response.json())
//                 .then((data) => {
//                     setIncidentCategories(data.incidentCategories);
//                 })
//                 .catch((error) => {
//                     console.error('Error fetching incident category:', error);
//                 });
//         }

//         if (incidentCategory) {
//             fetch(`http://localhost:8989/getIncidentSubCategories?incidentCategory=${incidentCategory}`)
//                 .then((response) => response.json())
//                 .then((data) => {
//                     setIncidentSubCategories(data);
//                 })
//                 .catch((error) => {
//                     console.error('Error fetching incident subcategories:', error);
//                 });
//         }
//     }, [incidentType, incidentCategory]);

//     const handleFieldChange = (label, value) => {
//         localStorage.setItem(label, value);
//         setSelectedValues((prev) => ({ ...prev, [label]: value }));
//     };

//     const handleIncidentTypeChange = (event) => {
//         const selectedIncidentType = event.target.value;
//         setIncidentType(selectedIncidentType);
//         handleFieldChange('Incident Type', selectedIncidentType);

//         setIncidentCategory('');
//         setIncidentSubCategory('');
//         setIncidentCategories([]);
//         setIncidentSubCategories([]);

//         fetch(`http://localhost:8989/incidentType?incidentType=${selectedIncidentType}`)
//             .then((response) => response.json())
//             .then((data) => {
//                 setIncidentCategories(data.incidentCategories);
//             })
//             .catch((error) => {
//                 console.error('Error fetching incident category:', error);
//             });
//     };

//     const handleIncidentCategoryChange = (event) => {
//         const selectedIncidentCategory = event.target.value;
//         setIncidentCategory(selectedIncidentCategory);
//         handleFieldChange('Incident Category', selectedIncidentCategory);
//         setIncidentSubCategory('');
//         setIncidentSubCategories([]);

//         fetch(`http://localhost:8989/getIncidentSubCategories?incidentCategory=${selectedIncidentCategory}`)
//             .then((response) => response.json())
//             .then((data) => {
//                 setIncidentSubCategories(data);
//             })
//             .catch((error) => {
//                 console.error('Error fetching incident subcategories:', error);
//             });
//     };

//     const renderField = (field) => {
//         switch (field.type) {
//             case 'textfield':
//                 return (
//                     <Grid item xs={12} sm={6} md={4} mt={2} key={field.id}>
//                         <Typography>{field.label}</Typography>
//                         <TextField
//                             fullWidth
//                             type="text"
//                             defaultValue={localStorage.getItem(field.label) || ''}
//                             sx={{ height: '30px', mb: 1 }}
//                             onChange={(e) => handleFieldChange(field.label, e.target.value)}
//                         />
//                     </Grid>
//                 );
//             case 'checklist':
//                 return (
//                     <Grid item xs={12} sm={6} md={4} mt={2} key={field.id}>
//                         <Typography>{field.label}</Typography>
//                         <FormGroup row>
//                             {field.values && field.values.map((option) => (
//                                 <FormControlLabel
//                                     key={option.value}
//                                     control={
//                                         <Checkbox
//                                             checked={localStorage.getItem(field.label)?.split(',').includes(option.value)}
//                                             onChange={(e) => {
//                                                 const currentValues = localStorage.getItem(field.label) || '';
//                                                 const newValues = e.target.checked
//                                                     ? [...currentValues.split(','), option.value] 
//                                                     : currentValues.split(',').filter(value => value !== option.value); 
//                                                 handleFieldChange(field.label, newValues.join(',')); 
//                                             }}
//                                             sx={{ '&.Mui-checked': { color: '#145A7B' }, }}
//                                         />
//                                     }
//                                     label={option.label}
//                                 />
//                             ))}
//                         </FormGroup>
//                     </Grid>
//                 );
//             case 'datetime':
//                 return (
//                     <Grid item xs={12} sm={6} md={4} mt={2} key={field.id}>
//                         <Typography>{field.subtype === 'time' ? field.timeLabel || field.label : field.dateLabel || field.label}</Typography>
//                         <TextField
//                             fullWidth
//                             type={field.subtype === 'date' ? 'date' : 'time'}
//                             defaultValue={localStorage.getItem(field.label) || ''}
//                             sx={{ height: '30px', mb: 1 }}
//                             onChange={(e) => handleFieldChange(field.label, e.target.value)}
//                         />
//                     </Grid>
//                 );
//             case 'select':
//                 return (
//                     <Grid item xs={12} sm={6} md={4} mt={2} key={field.id}>
//                         <Typography>{field.label}</Typography>
//                         <FormControl fullWidth>
//                             <Select
//                                 value={
//                                     field.label === 'Incident Type' ? incidentType
//                                         : field.label === 'Incident Category' ? incidentCategory
//                                             : field.label === 'Incident Sub-category' ? incidentSubCategory : selectedValues[field.label] || ''
//                                 }
//                                 onChange={(e) => {
//                                     const selectedValue = e.target.value;
//                                     if (field.label === 'Incident Type') {
//                                         handleIncidentTypeChange(e);
//                                     } else if (field.label === 'Incident Category') {
//                                         handleIncidentCategoryChange(e);
//                                     } else if (field.label === 'Incident Sub-category') {
//                                         handleFieldChange('Incident Sub-category', selectedValue);
//                                         setIncidentSubCategory(selectedValue);
//                                     } else {
//                                         handleFieldChange(field.label, selectedValue);
//                                         setSelectedValues((prev) => ({ ...prev, [field.label]: selectedValue }));
//                                     }
//                                 }}
//                             >
//                                 {field.label === 'Incident Type'
//                                     ? field.values.map((option) => (
//                                         <MenuItem key={option.value} value={option.value}>
//                                             {option.label}
//                                         </MenuItem>
//                                     ))
//                                     : field.label === 'Incident Category'
//                                         ? incidentCategories.map((option) => (
//                                             <MenuItem key={option} value={option}>
//                                                 {option}
//                                             </MenuItem>
//                                         ))
//                                         : field.label === 'Incident Sub-category'
//                                             ? incidentSubCategories.map((option) => (
//                                                 <MenuItem key={option} value={option}>
//                                                     {option}
//                                                 </MenuItem>
//                                             ))
//                                             : field.values && field.values.map((option) => (
//                                                 <MenuItem key={option.value} value={option.value}>
//                                                     {option.label}
//                                                 </MenuItem>
//                                             ))}
//                             </Select>
//                         </FormControl>
//                     </Grid>
//                 );
//             case 'textarea':
//                 return (
//                     <Grid item xs={12} sm={6} md={6} mt={2} key={field.id}>
//                         <Typography>{field.label}</Typography>
//                         <TextField
//                             fullWidth
//                             multiline
//                             rows={2}
//                             defaultValue={localStorage.getItem(field.label) || ''}
//                             sx={{ mb: 1 }}
//                             onChange={(e) => handleFieldChange(field.label, e.target.value)}
//                         />
//                     </Grid>
//                 );
//             default:
//                 return null;
//         }
//     };

//     return (
//         <Paper elevation={3} sx={{ p: 2 }}>
//             <Typography variant="h6" gutterBottom>
//                 Incident Details
//             </Typography>
//             <Grid container spacing={2}>
//                 {fields && fields.length > 0 && fields.map((field) => renderField(field))}
//             </Grid>
//         </Paper>
//     );
// };

// export default IncidentDetails;

// import React, { useEffect, useState } from 'react';
// import { Box, Grid, TextField, FormControl, Select, MenuItem, Paper, Typography, FormGroup, FormControlLabel, Checkbox } from '@mui/material';
// import { useNavigate } from 'react-router-dom';

// const IncidentDetails = () => {
//     const navigate = useNavigate();
//     const [fields, setFields] = useState([]);
//     const [incidentType, setIncidentType] = useState(localStorage.getItem('Incident Type') || '');
//     const [incidentCategory, setIncidentCategory] = useState(localStorage.getItem('Incident Category') || '');
//     const [incidentSubCategory, setIncidentSubCategory] = useState(localStorage.getItem('Incident Sub-category') || '');
//     const [incidentCategories, setIncidentCategories] = useState([]);
//     const [incidentSubCategories, setIncidentSubCategories] = useState([]);

//     const [selectedValues, setSelectedValues] = useState({});
//     const [businessid, setBusinessid] = useState("");
//     const currentDate = new Date();
//     const formattedDate = `${String(currentDate.getDate()).padStart(2, '0')}-${String(currentDate.getMonth() + 1).padStart(2, '0')}-${currentDate.getFullYear()}`; // DD-MM-YYYY
//     const formattedTime = currentDate.toTimeString().split(' ')[0].substring(0, 5).replace(':', ':'); // HH-mm

//     localStorage.setItem('Creation Date', formattedDate);
//     localStorage.setItem('Creation Time', formattedTime);

//     useEffect(() => {
//         const fetchedBusinessid = localStorage.getItem('businessid') || "";
//         setBusinessid(fetchedBusinessid);

//         if (fetchedBusinessid) {
//             fetch(`http://localhost:8989/getForms?formId=IncidentCreation&processDefinitionKey=${fetchedBusinessid}`)
//                 .then((response) => {
//                     if (!response.ok) {
//                         throw new Error('Network response was not ok');
//                     }
//                     return response.json();
//                 })
//                 .then((data) => {
//                     const schema = JSON.parse(data.schema);
//                     setFields(schema.components);
//                 })
//                 .catch((error) => console.error('Error fetching form data:', error));
//         }

//         // Set creation date and time in local storage on mount


//     }, []); // Run only once on mount

//     useEffect(() => {
//         // Re-fetch categories and subcategories if incidentType or incidentCategory are saved in localStorage
//         if (incidentType) {
//             fetch(`http://localhost:8989/incidentType?incidentType=${incidentType}`)
//                 .then((response) => response.json())
//                 .then((data) => {
//                     setIncidentCategories(data.incidentCategories);
//                 })
//                 .catch((error) => {
//                     console.error('Error fetching incident category:', error);
//                 });
//         }

//         if (incidentCategory) {
//             fetch(`http://localhost:8989/getIncidentSubCategories?incidentCategory=${incidentCategory}`)
//                 .then((response) => response.json())
//                 .then((data) => {
//                     setIncidentSubCategories(data);
//                 })
//                 .catch((error) => {
//                     console.error('Error fetching incident subcategories:', error);
//                 });
//         }
//     }, [incidentType, incidentCategory]);

//     const handleFieldChange = (label, value) => {
//         localStorage.setItem(label, value);
//         setSelectedValues((prev) => ({ ...prev, [label]: value }));
//     };

//     const handleIncidentTypeChange = (event) => {
//         const selectedIncidentType = event.target.value;
//         setIncidentType(selectedIncidentType);
//         handleFieldChange('Incident Type', selectedIncidentType);

//         setIncidentCategory('');
//         setIncidentSubCategory('');
//         setIncidentCategories([]);
//         setIncidentSubCategories([]);

//         fetch(`http://localhost:8989/incidentType?incidentType=${selectedIncidentType}`)
//             .then((response) => response.json())
//             .then((data) => {
//                 setIncidentCategories(data.incidentCategories);
//             })
//             .catch((error) => {
//                 console.error('Error fetching incident category:', error);
//             });
//     };

//     const handleIncidentCategoryChange = (event) => {
//         const selectedIncidentCategory = event.target.value;
//         setIncidentCategory(selectedIncidentCategory);
//         handleFieldChange('Incident Category', selectedIncidentCategory);
//         setIncidentSubCategory('');
//         setIncidentSubCategories([]);

//         fetch(`http://localhost:8989/getIncidentSubCategories?incidentCategory=${selectedIncidentCategory}`)
//             .then((response) => response.json())
//             .then((data) => {
//                 setIncidentSubCategories(data);
//             })
//             .catch((error) => {
//                 console.error('Error fetching incident subcategories:', error);
//             });
//     };

//     const renderField = (field) => {
//         switch (field.type) {
//             case 'textfield':
//                 return (
//                     <Grid item xs={12} sm={6} md={4} mt={2} key={field.id}>
//                         <Typography>{field.label}</Typography>
//                         <TextField
//                             fullWidth
//                             type="text"
//                             defaultValue={localStorage.getItem(field.label) || ''}
//                             sx={{ height: '30px', mb: 1 }}
//                             onChange={(e) => handleFieldChange(field.label, e.target.value)}
//                         />
//                     </Grid>
//                 );
//             case 'checklist':
//                 return (
//                     <Grid item xs={12} sm={6} md={4} mt={2} key={field.id}>
//                         <Typography>{field.label}</Typography>
//                         <FormGroup row>
//                             {field.values && field.values.map((option) => (
//                                 <FormControlLabel
//                                     key={option.value}
//                                     control={
//                                         <Checkbox
//                                             checked={localStorage.getItem(field.label)?.split(',').includes(option.value)}
//                                             onChange={(e) => {
//                                                 const currentValues = localStorage.getItem(field.label) || '';
//                                                 const newValues = e.target.checked
//                                                     ? [...currentValues.split(','), option.value]
//                                                     : currentValues.split(',').filter(value => value !== option.value);
//                                                 handleFieldChange(field.label, newValues.join(','));
//                                             }}
//                                             sx={{ '&.Mui-checked': { color: '#145A7B' }, }}
//                                         />
//                                     }
//                                     label={option.label}
//                                 />
//                             ))}
//                         </FormGroup>
//                     </Grid>
//                 );
//             case 'select':
//                 return (
//                     <Grid item xs={12} sm={6} md={4} mt={2} key={field.id}>
//                         <Typography>{field.label}</Typography>
//                         <FormControl fullWidth >
//                             <Select value={
//                                 field.label === 'Incident Type' ? incidentType
//                                     : field.label === 'Incident Category' ? incidentCategory
//                                         : field.label === 'Incident Sub-category' ? incidentSubCategory : localStorage.getItem(field.label) || ''}
//                                 onChange={(e) => {
//                                     const selectedValue = e.target.value;
//                                     const updatedValues = { ...selectedValues, [field.label]: selectedValue };
//                                     setSelectedValues(updatedValues);
//                                     localStorage.setItem(field.label, selectedValue);
//                                     if (field.label === 'Incident Type') {
//                                         handleIncidentTypeChange(e);
//                                     } else if (field.label === 'Incident Category') {
//                                         handleIncidentCategoryChange(e);
//                                     } else if (field.label === 'Incident Sub-category') {
//                                         handleFieldChange('Incident Sub-category', selectedValue);
//                                         setIncidentSubCategory(selectedValue);
//                                     }
//                                 }}
//                             >
//                                 {field.label === 'Incident Type'
//                                     ? field.values.map((option) => (
//                                         <MenuItem key={option.value} value={option.value}>
//                                             {option.label}
//                                         </MenuItem>
//                                     ))
//                                     : field.label === 'Incident Category'
//                                         ? incidentCategories.map((option) => (
//                                             <MenuItem key={option} value={option}>
//                                                 {option}
//                                             </MenuItem>
//                                         ))
//                                         : field.label === 'Incident Sub-category'
//                                             ? incidentSubCategories.map((option) => (
//                                                 <MenuItem key={option} value={option}>
//                                                     {option}
//                                                 </MenuItem>
//                                             ))
//                                             : field.values && field.values.map((option) => (
//                                                 <MenuItem key={option.value} value={option.value}>
//                                                     {option.label}
//                                                 </MenuItem>
//                                             ))}
//                             </Select>
//                         </FormControl>
//                     </Grid>
//                 );
//             case 'textarea':
//                 return (
//                     <Grid item xs={12} sm={6} md={6} mt={2} key={field.id}>
//                         <Typography>{field.label}</Typography>
//                         <TextField
//                             fullWidth
//                             multiline
//                             rows={2}
//                             defaultValue={localStorage.getItem(field.label) || ''}
//                             sx={{ mb: 1 }}
//                             onChange={(e) => handleFieldChange(field.label, e.target.value)}
//                         />
//                     </Grid>
//                 );
//             default:
//                 return null;
//         }
//     };



//     return (
//         <Box sx={{ justifyContent: 'center', alignItems: 'center', marginRight: 6 }}>
//         <Paper elevation={2} sx={{ padding: '30px', backgroundColor: 'white', borderRadius: '8px', overflow: 'auto' }}>
//             <Typography variant="h4" sx={{ flexGrow: 1, marginLeft: '0px', paddingBottom: '20px' }}>
//                 Incident Details
//             </Typography>
//             <Box component="form">
//                 <Grid container spacing={2}>

//                     <Grid item xs={12} sm={6} md={4} mt={2}>
//                         <Typography>Creation Date</Typography>
//                         <TextField fullWidth type="text" value={localStorage.getItem('Creation Date') || formattedDate}
//                             sx={{ height: '30px', mb: 1 }}
//                             InputProps={{ readOnly: true, }}
//                         />
//                     </Grid>
//                     <Grid item xs={12} sm={6} md={4} mt={2}>
//                         <Typography>Incident Date</Typography>
//                         <TextField fullWidth type="date" defaultValue={localStorage.getItem('Incident Date')} onChange={(e) => handleFieldChange('Incident Date', e.target.value)}
//                             sx={{ height: '30px', mb: 1 }}
//                         />
//                     </Grid>
//                     <Grid item xs={12} sm={6} md={4} mt={2}>
//                         <Typography>Creation Time</Typography>
//                         <TextField fullWidth type="text" value={localStorage.getItem('Creation Time') || formattedTime}
//                             sx={{ height: '30px', mb: 1 }} InputProps={{ readOnly: true, }}
//                         />
//                     </Grid>
//                     <Grid item xs={12} sm={6} md={4} mt={2}>
//                         <Typography>Incident Time</Typography>
//                         <TextField fullWidth type="time" value={localStorage.getItem('Incident Time')}
//                             sx={{ height: '30px', mb: 1 }} onChange={(e) => handleFieldChange('Incident Time', e.target.value)} inputProps={{ step: 60, }}
//                         />
//                     </Grid>
//                     {fields.map(renderField)}
//                 </Grid>
//             </Box>
//         </Paper>
//         </Box>
//     );
// };

// export default IncidentDetails;

import React, { useEffect, useState } from 'react';
import { Box, Grid, TextField, FormControl, Select, MenuItem, Paper, Typography, FormGroup, FormControlLabel, Checkbox, CircularProgress } from '@mui/material';
import { useNavigate } from 'react-router-dom';

const IncidentDetails = () => {
    const navigate = useNavigate();
    const [fields, setFields] = useState([]);
    const [incidentType, setIncidentType] = useState(localStorage.getItem('Incident Type') || '');
    const [incidentCategory, setIncidentCategory] = useState(localStorage.getItem('Incident Category') || '');
    const [incidentSubCategory, setIncidentSubCategory] = useState(localStorage.getItem('Incident Sub-category') || '');
    const [incidentCategories, setIncidentCategories] = useState([]);
    const [incidentSubCategories, setIncidentSubCategories] = useState([]);
    
    const [selectedValues, setSelectedValues] = useState({});
    const [businessid, setBusinessid] = useState("");
    const [loading, setLoading] = useState(true); // Loading state
    const currentDate = new Date();
    const formattedDate = `${String(currentDate.getDate()).padStart(2, '0')}-${String(currentDate.getMonth() + 1).padStart(2, '0')}-${currentDate.getFullYear()}`; // DD-MM-YYYY
    const formattedTime = currentDate.toTimeString().split(' ')[0].substring(0, 5).replace(':', ':'); // HH-mm

    localStorage.setItem('Creation Date', formattedDate);
    localStorage.setItem('Creation Time', formattedTime);

    useEffect(() => {
        const fetchedBusinessid = localStorage.getItem('businessid') || "";
        setBusinessid(fetchedBusinessid);

        if (fetchedBusinessid) {
            setLoading(true); 
            fetch(`http://localhost:8989/getForms?formId=IncidentCreation&processDefinitionKey=${fetchedBusinessid}`)
                .then((response) => {
                    if (!response.ok) {
                        throw new Error('Network response was not ok');
                    }
                    return response.json();
                })
                .then((data) => {
                    const schema = JSON.parse(data.schema);
                    setFields(schema.components);
                    setLoading(false); // Stop loading
                })
                .catch((error) => {
                    console.error('Error fetching form data:', error);
                    setLoading(false); // Stop loading even if there's an error
                });
        }

    }, []); // Run only once on mount

    useEffect(() => {
        if (incidentType) {
              fetch(`http://localhost:8989/incidentType?incidentType=${incidentType}`)
                .then((response) => response.json())
                .then((data) => {
                    setIncidentCategories(data.incidentCategories);
                })
                .catch((error) => {
                    console.error('Error fetching incident category:', error);
                });
        }

        if (incidentCategory) {
            fetch(`http://localhost:8989/getIncidentSubCategories?incidentCategory=${incidentCategory}`)
                .then((response) => response.json())
                .then((data) => {
                    setIncidentSubCategories(data);
                })
                .catch((error) => {
                    console.error('Error fetching incident subcategories:', error);
                });
        }
    }, [incidentType, incidentCategory]);

    const handleFieldChange = (label, value) => {
        localStorage.setItem(label, value);
        setSelectedValues((prev) => ({ ...prev, [label]: value }));
    };

    const handleIncidentTypeChange = (event) => {
        const selectedIncidentType = event.target.value;
        setIncidentType(selectedIncidentType);
        handleFieldChange('Incident Type', selectedIncidentType);

        setIncidentCategory('');
        setIncidentSubCategory('');
        setIncidentCategories([]);
        setIncidentSubCategories([]);
        fetch(`http://localhost:8989/incidentType?incidentType=${selectedIncidentType}`)
            .then((response) => response.json())
            .then((data) => {
                setIncidentCategories(data.incidentCategories);
            })
            .catch((error) => {
                console.error('Error fetching incident category:', error);
            });
    };

    const handleIncidentCategoryChange = (event) => {
        const selectedIncidentCategory = event.target.value;
        setIncidentCategory(selectedIncidentCategory);
        handleFieldChange('Incident Category', selectedIncidentCategory);
        setIncidentSubCategory('');
        setIncidentSubCategories([]);
        fetch(`http://localhost:8989/getIncidentSubCategories?incidentCategory=${selectedIncidentCategory}`)
            .then((response) => response.json())
            .then((data) => {
                setIncidentSubCategories(data);
            })
            .catch((error) => {
                console.error('Error fetching incident subcategories:', error);
            });
    };

    const renderField = (field) => {
        switch (field.type) {
            case 'textfield':
                return (
                    <Grid item xs={12} sm={6} md={4} mt={2} key={field.id}>
                        <Typography>{field.label}</Typography>
                        <TextField
                            fullWidth
                            type="text"
                            defaultValue={localStorage.getItem(field.label) || ''}
                            sx={{ height: '30px', mb: 1 }}
                            onChange={(e) => handleFieldChange(field.label, e.target.value)}
                        />
                    </Grid>
                );
                case 'checklist':
                    return (
                        <Grid item xs={12} sm={6} md={4} mt={2} key={field.id}>
                            <Typography>{field.label}</Typography>
                            <FormGroup row>
                                {field.values && field.values.map((option) => {
                                    // Retrieve and clean the stored values
                                    const storedValues = localStorage.getItem(field.label) || '';
                                    const cleanedValues = storedValues.replace(/^,/, ''); // Remove the first comma if it exists
                                    const currentValues = cleanedValues.split(',').filter(Boolean); // Split and filter empty strings
                
                                    return (
                                        <FormControlLabel
                                            key={option.value}
                                            control={
                                                <Checkbox
                                                    checked={currentValues.includes(option.value)}
                                                    onChange={(e) => {
                                                        const newValues = e.target.checked
                                                            ? [...currentValues, option.value] // Append new value
                                                            : currentValues.filter(value => value !== option.value); // Remove the value
                
                                                        // Join and ensure there are no leading commas
                                                        handleFieldChange(field.label, newValues.join(',').replace(/^,/, ''));
                                                    }}
                                                    sx={{ '&.Mui-checked': { color: '#145A7B' } }}
                                                />
                                            }
                                            label={option.label}
                                        />
                                    );
                                })}
                            </FormGroup>
                        </Grid>
                    );
                
            case 'select':
                return (
                    <Grid item xs={12} sm={6} md={4} mt={2} key={field.id}>
                        <Typography>{field.label}</Typography>
                        <FormControl fullWidth >
                            <Select value={
                                field.label === 'Incident Type' ? incidentType
                                    : field.label === 'Incident Category' ? incidentCategory
                                        : field.label === 'Incident Sub-category' ? incidentSubCategory : localStorage.getItem(field.label) || ''}
                                onChange={(e) => {
                                    const selectedValue = e.target.value;
                                    const updatedValues = { ...selectedValues, [field.label]: selectedValue };
                                    setSelectedValues(updatedValues);
                                    localStorage.setItem(field.label, selectedValue);
                                    if (field.label === 'Incident Type') {
                                        handleIncidentTypeChange(e);
                                    } else if (field.label === 'Incident Category') {
                                        handleIncidentCategoryChange(e);
                                    } else if (field.label === 'Incident Sub-category') {
                                        handleFieldChange('Incident Sub-category', selectedValue);
                                        setIncidentSubCategory(selectedValue);
                                    }
                                }}
                            >
                                {field.label === 'Incident Type'
                                    ? field.values.map((option) => (
                                        <MenuItem key={option.value} value={option.value}>
                                            {option.label}
                                        </MenuItem>
                                    ))
                                    : field.label === 'Incident Category'
                                        ? incidentCategories.map((option) => (
                                            <MenuItem key={option} value={option}>
                                                {option}
                                            </MenuItem>
                                        ))
                                        : field.label === 'Incident Sub-category'
                                            ? incidentSubCategories.map((option) => (
                                                <MenuItem key={option} value={option}>
                                                    {option}
                                                </MenuItem>
                                            ))
                                            : field.values && field.values.map((option) => (
                                                <MenuItem key={option.value} value={option.value}>
                                                    {option.label}
                                                </MenuItem>
                                            ))}
                            </Select>
                        </FormControl>
                    </Grid>
                );
            case 'textarea':
                return (
                    <Grid item xs={12} sm={6} md={6} mt={2} key={field.id}>
                        <Typography>{field.label}</Typography>
                        <TextField
                            fullWidth
                            multiline
                            rows={2}
                            defaultValue={localStorage.getItem(field.label) || ''}
                            sx={{ mb: 1 }}
                            onChange={(e) => handleFieldChange(field.label, e.target.value)}
                        />
                    </Grid>
                );
            default:
                return null;
        }
    };

     if (loading) {
        return (
            <Box sx={{ display: 'flex', justifyContent: 'center', alignItems: 'center', height: '100vh' }}>
                <CircularProgress color="inherit" size="4rem"/>
            </Box>
        );
    }

    return (
        <Box sx={{ justifyContent: 'center', alignItems: 'center', marginRight: 6 }}>
            <Paper elevation={2} sx={{ padding: '30px', backgroundColor: 'white', borderRadius: '8px', overflow: 'auto' }}>
                <Typography variant="h4" sx={{ flexGrow: 1, marginLeft: '0px', paddingBottom: '20px' }}>
                    Incident Details
                </Typography>
                <Box component="form">
                    <Grid container spacing={2}>
                        <Grid item xs={12} sm={6} md={4} mt={2}>
                            <Typography>Creation Date</Typography>
                            <TextField fullWidth type="text" value={localStorage.getItem('Creation Date') || formattedDate}
                                sx={{ height: '30px', mb: 1 }}
                                InputProps={{ readOnly: true, }}
                            />
                        </Grid>
                        <Grid item xs={12} sm={6} md={4} mt={2}>
                            <Typography>Incident Date</Typography>
                            <TextField fullWidth type="date" defaultValue={localStorage.getItem('Incident Date')} onChange={(e) => handleFieldChange('Incident Date', e.target.value)}
                                sx={{ height: '30px', mb: 1 }}
                            />
                        </Grid>
                        <Grid item xs={12} sm={6} md={4} mt={2}>
                            <Typography>Creation Time</Typography>
                            <TextField fullWidth type="text" value={localStorage.getItem('Creation Time') || formattedTime}
                                sx={{ height: '30px', mb: 1 }} InputProps={{ readOnly: true, }}
                            />
                        </Grid>
                        <Grid item xs={12} sm={6} md={4} mt={2}>
                            <Typography>Incident Time</Typography>
                            <TextField fullWidth type="time" value={localStorage.getItem('Incident Time')}
                                sx={{ height: '30px', mb: 1 }} onChange={(e) => handleFieldChange('Incident Time', e.target.value)} inputProps={{ step: 60, }}
                            />
                        </Grid>
                        {fields.map(renderField)}
                    </Grid>
                </Box>
            </Paper>
        </Box>
    );
};

export default IncidentDetails;
