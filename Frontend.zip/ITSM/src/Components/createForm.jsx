import React, { useState } from 'react';
import { TextField, MenuItem, FormControl, InputLabel, Select, Button, Grid, RadioGroup, AccordionDetails, DialogTitle, Accordion, AccordionSummary, DialogContent, DialogActions, FormControlLabel, FormLabel, Radio, Box, Dialog, Paper, Divider, IconButton, Typography } from '@mui/material';
import ArrowBackIcon from '@mui/icons-material/ArrowBack';
import AddIcon from '@mui/icons-material/Add';
import ArrowDropDownIcon from '@mui/icons-material/ArrowDropDown';
import DeleteIcon from '@mui/icons-material/Delete';
const IncidentForm = () => {
    const [formData, setFormData] = useState({
        CreationDate: '',
        CreationTime: '',
        IncidentDate: '',
        IncidentTime: '',
        Staffinvolvedname: '',
        Staffrole: '',
        IncidentType: '',
        Locationoftheincident: '',
        IncidentSubCategory: '',
        IncidentDescription: '',
        InitialActionTaken: '',
        Description: '',
        PatientID: '',
        PatientName: '',
        PatientAge: '',
        PatientGender: '',
        State: '',
        City: '',
        Branch: '',
        Department: '',
        Floor: '',
        Block: '',
        ContactNumber: '',
        FamilyContactNumber: '',
        MedicationClass: ''
    });
    const [images, setImages] = useState([]);
    const [previewImage, setPreviewImage] = useState(null);
    const [open, setOpen] = useState(false);
    const [isDialogOpen, setIsDialogOpen] = useState(false);
    const handleChange = (e) => {
        const { name, value } = e.target;
        setFormData((prevState) => ({
            ...prevState,
            [name]: value
        }));
    };
    const handleImageUpload = (event) => {
        const files = Array.from(event.target.files);
        const newImages = files.map((file) => {
            const reader = new FileReader();
            return new Promise((resolve, reject) => {
                reader.onloadend = () => resolve(reader.result);
                reader.onerror = reject;
                reader.readAsDataURL(file);
            });
        });
        Promise.all(newImages).then((urls) => setImages((prevImages) => [...prevImages, ...urls]));
    };
    const handleImageRemove = (index) => {
        setImages((prevImages) => prevImages.filter((_, i) => i !== index));
    };

    const handleClose = () => {
        setIsDialogOpen(false);
        setOpen(false);
        setPreviewImage(null);

    };
    const handleImageClick = (image) => {
        setPreviewImage(image);
        setOpen(true);
    };
    const handleSubmit = () => {
        // Handle form submission logic here
        console.log(formData);
    };

    return (
        <Box sx={{ display: 'flex', justifyContent: 'center', alignItems: 'center', backgroundColor: '#f4f4f4', padding: '10px', paddingTop: "10px", height: "90vh" }}>
            <Paper elevation={10} sx={{ width: '95%', padding: '15px', backgroundColor: '#DEECF1', borderRadius: '8px', height: "95%", display: 'flex', flexDirection: 'column' }}>
                <Box mb={-4} display="flex" alignItems="center">
                    <IconButton onClick={() => navigate('/dashboard')}>
                        <ArrowBackIcon sx={{ cursor: 'pointer', mr: -2 }} />
                    </IconButton>
                    <Button variant="text" sx={{ color: 'black', fontWeight: 'bold' }} onClick={() => navigate('/dashboard')}>
                        Back
                    </Button>
                </Box>
                <Box >
                <Typography variant="h4" fontWeight='bold' sx={{paddingTop:"20px"}}>Create Case</Typography>
                </Box>
                <Box sx={{ flex: 1, display: 'flex', flexDirection: 'column', overflowY: 'auto',}}>
                    <Paper elevation={2} sx={{ padding: '20px', backgroundColor: 'white', borderRadius: '8px', height: "90vh" }}>
                        <form onSubmit={handleSubmit}>

                            <Accordion elevation={4} defaultExpanded={true} sx={{ backgroundColor: '#DEECF1', borderRadius: '8px', }}>
                                <AccordionSummary expandIcon={<ArrowDropDownIcon fontSize="large" />} sx={{ backgroundColor: '#DEECF1', height: "50px", paddingTop: "10px", paddingLeft: "25px", borderColor: "black", borderRadius: "200px" }}>
                                    <Typography variant="h6" fontWeight='bold'>Incident Details</Typography>
                                </AccordionSummary>
                                <AccordionDetails sx={{ backgroundColor: 'white', }}><Grid container spacing={3}>
                                    {/* Creation Date */}
                                    <Grid item xs={6} sm={3}>
                                        <TextField label="Creation Date" type="date" name="CreationDate" value={formData.CreationDate} onChange={handleChange} fullWidth InputLabelProps={{ shrink: true }}
                                        />
                                    </Grid>
                                    {/* Creation Time */}
                                    <Grid item xs={6} sm={3}>
                                        <TextField label="Creation Time" type="time" name="CreationTime" value={formData.CreationTime} onChange={handleChange} fullWidth InputLabelProps={{ shrink: true }}
                                        />
                                    </Grid>
                                    {/* Incident Date */}
                                    <Grid item xs={6} sm={3}>
                                        <TextField label="Incident Date" type="date" name="IncidentDate" value={formData.IncidentDate} onChange={handleChange} fullWidth InputLabelProps={{ shrink: true }}
                                        />
                                    </Grid>
                                    {/* Incident Time */}
                                    <Grid item xs={6} sm={3}>
                                        <TextField label="Incident Time" type="time" name="IncidentTime" value={formData.IncidentTime} onChange={handleChange} fullWidth InputLabelProps={{ shrink: true }}
                                        />
                                    </Grid>
                                    {/* Incident Type */}
                                    <Grid item xs={6} sm={3}>
                                        <FormControl fullWidth>

                                            <InputLabel>Incident Type</InputLabel>
                                            <Select name="IncidentType" value={formData.IncidentType} onChange={handleChange}
                                            >
                                                <MenuItem value="type1">Type 1</MenuItem>
                                                <MenuItem value="type2">Type 2</MenuItem>
                                                {/* Add more options as needed */}
                                            </Select>
                                        </FormControl>
                                    </Grid>
                                    {/* Location of Incident */}
                                    <Grid item xs={6} sm={3}>
                                        <TextField label="Location of the Incident" name="Locationoftheincident" value={formData.Locationoftheincident} onChange={handleChange} fullWidth
                                        />
                                    </Grid>
                                    <Grid item xs={6} sm={3}>
                                        <FormControl fullWidth>
                                            <InputLabel>Incident category</InputLabel>
                                            <Select name="IncidentSubCategory" value={formData.IncidentCategory} onChange={handleChange}
                                            >
                                                <MenuItem value="subcat1">Sub-category 1</MenuItem>
                                                <MenuItem value="subcat2">Sub-category 2</MenuItem>
                                                {/* Add more options as needed */}
                                            </Select>
                                        </FormControl>
                                    </Grid>
                                    {/* Incident Sub-category */}
                                    <Grid item xs={6} sm={3}>
                                        <FormControl fullWidth>
                                            <InputLabel>Incident Sub-category</InputLabel>
                                            <Select name="IncidentSubCategory" value={formData.IncidentSubCategory} onChange={handleChange}
                                            >
                                                <MenuItem value="subcat1">Sub-category 1</MenuItem>
                                                <MenuItem value="subcat2">Sub-category 2</MenuItem>
                                                {/* Add more options as needed */}
                                            </Select>
                                        </FormControl>
                                    </Grid>
                                    {/* Incident Description */}
                                    <Grid item xs={12} sm={6}>
                                        <TextField label="Incident Description" name="IncidentDescription" value={formData.IncidentDescription} onChange={handleChange} fullWidth multiline rows={1}
                                        />
                                    </Grid>
                                    {/* Description
                            <Grid item xs={12} sm={6}>
                                <TextField label="Description" name="Description" value={formData.Description} onChange={handleChange} fullWidth multiline rows={4}
                                />
                            </Grid> */}

                                    {/* Initial Action Taken */}
                                    <Grid item xs={12} sm={6}>
                                        <TextField label="Initial Action Taken" name="InitialActionTaken" value={formData.InitialActionTaken} onChange={handleChange} fullWidth
                                        />
                                    </Grid>
                                    <Grid item xs={12} sm={12}>
                                        <TextField label="Initial Action Taken" name="InitialActionTaken" value={formData.InitialActionTaken} onChange={handleChange} fullWidth multiline rows={3}
                                        />
                                    </Grid>
                                </Grid>
                                </AccordionDetails>
                            </Accordion>
                            <Grid item xs={12}>
                                <Divider style={{ backgroundColor: 'black', margin: '10px' }} />

                            </Grid>
                            <Accordion elevation={4} sx={{ backgroundColor: '#DEECF1', borderRadius: '8px', }}>
                                <AccordionSummary expandIcon={<ArrowDropDownIcon fontSize="large" />} sx={{ backgroundColor: '#DEECF1', height: "50px", paddingTop: "10px", paddingLeft: "25px", borderColor: "black", borderRadius: "200px" }}>
                                    <Typography variant="h6" fontWeight='bold'>Patient Details</Typography>
                                </AccordionSummary>
                                <AccordionDetails sx={{ backgroundColor: 'white', }}>
                                    <Grid container spacing={3}>
                                        {/* <Grid item xs={12}>
                                    <Divider style={{ backgroundColor: 'black', margin: '10px' }} />
                                    <Typography variant="h6" fontWeight='bold'>Patient Details</Typography>
                                </Grid> */}
                                        {/* Patient ID */}
                                        <Grid item xs={6} sm={3}>
                                            <TextField label="Patient ID" name="PatientID" value={formData.PatientID} onChange={handleChange} fullWidth
                                            />
                                        </Grid>
                                        {/* Patient Name */}
                                        <Grid item xs={6} sm={3}>
                                            <TextField label="Patient Name" name="PatientName" value={formData.PatientName} onChange={handleChange} fullWidth
                                            />
                                        </Grid>
                                        {/* Patient Age */}
                                        <Grid item xs={6} sm={3}>
                                            <TextField label="Patient Age" name="PatientAge" value={formData.PatientAge} onChange={handleChange} fullWidth
                                            />
                                        </Grid>
                                        <Grid item xs={6} sm={3}>
                                            <FormControl component="fieldset">
                                                {/* Label for the RadioGroup */}
                                                <FormLabel component="legend">Patient Gender</FormLabel>

                                                {/* RadioGroup aligned horizontally */}
                                                <RadioGroup
                                                    row
                                                    name="PatientGender"
                                                    value={formData.PatientGender}
                                                    onChange={handleChange}
                                                >
                                                    <FormControlLabel value="Male" control={<Radio />} label="Male" />
                                                    <FormControlLabel value="Female" control={<Radio />} label="Female" />
                                                </RadioGroup>
                                            </FormControl>
                                        </Grid>
                                        <Grid item xs={6} sm={3}>
                                            <TextField label="Contact Number" name="ContactNumber" value={formData.ContactNumber} onChange={handleChange} fullWidth type="tel" inputProps={{ pattern: "[0-9]{3}-[0-9]{3}-[0-9]{4}" }} // optional pattern for validation (like XXX-XXX-XXXX)
                                            />
                                        </Grid>
                                        {/* Family Contact Number */}
                                        <Grid item xs={6} sm={3}>
                                            <TextField label="Family Contact Number" name="FamilyContactNumber" value={formData.FamilyContactNumber} onChange={handleChange} fullWidth
                                                type="tel" inputProps={{ pattern: "[0-9]{3}-[0-9]{3}-[0-9]{4}" }} // optional pattern for validation (like XXX-XXX-XXXX)
                                            />
                                        </Grid>
                                    </Grid>
                                </AccordionDetails>
                            </Accordion>
                            <Grid item xs={12}>
                                <Divider style={{ backgroundColor: 'black', margin: '10px' }} />
                                <Typography variant="h6" fontWeight='bold' sx={{ padding: "15px" }}>Attachments</Typography>
                                <InputLabel variant="h6" sx={{ fontWeight: 'bold' }}></InputLabel>
                                <Button
                                    variant="outlined"
                                    component="label"
                                    startIcon={<AddIcon />}
                                    sx={{
                                        color: 'black',
                                        paddingTop: "10px",
                                        borderColor: 'black',
                                        textTransform: 'none',
                                        '&:hover': {
                                            borderColor: 'black',
                                            backgroundColor: 'rgba(0, 0, 0, 0.1)',
                                        },
                                    }}
                                >
                                    Attach Evidence
                                    <input type="file" accept="image/*" hidden multiple onChange={handleImageUpload} />
                                </Button>
                                <Box mt={2} display="flex" flexWrap="wrap" gap={2}>
                                    {images.map((image, index) => (
                                        <Box key={index} sx={{ position: 'relative', width: '100px', height: '100px' }}>
                                            <img src={image} alt={`attachment-${index}`} style={{ width: '100%', height: '100%', objectFit: 'cover' }} onClick={() => handleImageClick(image)} />
                                            <IconButton
                                                onClick={() => handleImageRemove(index)}
                                                sx={{ position: 'absolute', top: 0, right: 0, color: 'red' }}
                                            >
                                                <DeleteIcon />
                                            </IconButton>
                                        </Box>
                                    ))}
                                </Box>
                            </Grid>
                            <Grid item xs={12}>
                                <Divider style={{ backgroundColor: 'black', margin: '10px' }} />
                            </Grid>
                            <Dialog open={open} onClose={handleClose} maxWidth="md" fullWidth>
                                <DialogTitle>Image Preview</DialogTitle>
                                <DialogContent>
                                    {previewImage && (
                                        <img src={previewImage} alt="Preview" style={{ width: '100%', height: '100%', objectFit: 'contain' }} />
                                    )}
                                </DialogContent>
                                <DialogActions>
                                    <Button onClick={handleClose} color="black">Close</Button>
                                </DialogActions>
                            </Dialog>

                        </form>
                        <Grid >
                            <Box sx={{ position: 'sticky', bottom: 10, right: 10, padding: "10px", zIndex: 10, display: 'flex', justifyContent: 'flex-end', }}
                            >
                                <Button
                                    width="10vw"
                                    variant="contained"
                                    onClick={handleSubmit}
                                    sx={{
                                        backgroundColor: 'black',
                                        color: 'white',
                                        textTransform: 'none',
                                        '&:hover': {
                                            backgroundColor: 'rgba(0, 0, 0, 0.8)',
                                        },
                                    }}
                                >
                                    Submit
                                </Button>
                            </Box>
                        </Grid>
                    </Paper>
                </Box>


            </Paper >
        </Box >
    );
};

export default IncidentForm;
