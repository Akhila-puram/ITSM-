import React, { useState } from "react";
import { useLocation, useNavigate } from "react-router-dom";
import { Box, Grid, Typography } from "@mui/material";
import Stepper from "@mui/material/Stepper";
import Step from "@mui/material/Step";
import StepLabel from "@mui/material/StepLabel";
import { styled } from "@mui/material/styles";
import Button from "@mui/material/Button";
import IncidentDetails from "./IncidentDetails";
import PatientDetails from "./PatientDetails";
import LocationUpdate from "./LocationUpdate";
import { SnackContext } from "./GlobalComponents/SnackProvider";
import axios from 'axios';

const steps = ["Incident Details", "Patient Details", "Location Update"];

const StyledButton = styled(Button)(({ theme }) => ({
  backgroundColor: "#4D99BD",
  padding: "8px 30px",
  textAlign: "center",
  color: "white",
  fontWeight: 600,
  fontSize: "0.8rem",
  borderRadius: "2em",
  border: "1px solid #145A7B",
  "&:hover": { backgroundColor: "#145A7B", color: "White", },
}));

const SecondaryButton = styled(Button)(({ theme }) => ({
  padding: "8px 30px",
  textAlign: "center",
  color: "#4D99BD",
  fontWeight: 600,
  fontSize: "0.8rem",
  borderRadius: "2em",
  border: "1px solid #145A7B",
  "&:hover": { backgroundColor: "#4D99BD", color: "White", },
}));

const CustomStep = styled(Step)(({ theme }) => ({
  display: "flex",
  flexDirection: "column",
  alignItems: "center",
}));

const CustomStepLabel = styled(StepLabel)(({ theme }) => ({
  display: "flex",
  flexDirection: "column",
  color: "#795548",
  alignItems: "center",
  marginTop: theme.spacing(2),
  "& .MuiStepIcon-root": { marginBottom: theme.spacing(1), },
}));

export default function HorizontalLinearStepper() {
  const [activeStep, setActiveStep] = useState(0);
  const navigate = useNavigate();
  const location = useLocation();
  const businessid = location.state?.businessid; 
  const { setSnack } = React.useContext(SnackContext);
  const newbusinessKey = localStorage.getItem("newbusinessKey"); 
  const isStepOptional = (step) => step === 1;
  console.log('Business Key:', businessid); 
  

  const handleNext = async () => {
    try {
       if (activeStep === steps.length - 1) {
        const creationDate = localStorage.getItem('Creation Date')?.split('-').reverse().join('-');
        const creationTime = `${localStorage.getItem('Creation Time')}:00`;
        const incidentDate = localStorage.getItem('Incident Date');
        const incidentTime = `${localStorage.getItem('Incident Time')}:00`;
        const incidentType = localStorage.getItem('Incident Type');
        const incidentCategory = localStorage.getItem('Incident Category');
        const incidentSubCategory = localStorage.getItem('Incident Sub-category');
        const medicationClass = localStorage.getItem('Medication Class');
        const reportedBy = localStorage.getItem('Reported by');
        const incidentDescription = localStorage.getItem('Incident Description');
        const initialActionTaken = localStorage.getItem('Initial Action Taken');
        const patientId = localStorage.getItem('Patient ID');
        const name = localStorage.getItem('Name');
        const age = localStorage.getItem('Age');
        const gender = localStorage.getItem('Gender');
        const contactNo = localStorage.getItem('Contact No');
        const familyContactNo = localStorage.getItem('Family Contact No');
        const patientCondition = localStorage.getItem('patientCondition');
        const blockRoomNo = localStorage.getItem('Block/Room No');
        const floor = localStorage.getItem('Floor');
        const branch = localStorage.getItem('Branch');
        const department = localStorage.getItem('Department');
        const city = localStorage.getItem('City');
        const state = localStorage.getItem('State');
        const communicationChannel = ["Whatsapp","Mail","SMS"];
        const requestBody = {
          incidentCreationDTO: {creationDate, creationTime,incidentDate,incidentTime,incidentType,incidentCategory,incidentSubCategory,medicationClass,reportedBy,incidentDescription,initialActionTaken, communicationChannel},
          patientDetailsDTO: { patientId, name, age, gender, contactNo, familyContactNo, patientCondition},
          locationDetailsDTO: { blockRoomNo, floor,branch, department,city, state }
        };
        const response = await axios.post(`http://localhost:8989/Testingcompleteids?processInstanceKey=${newbusinessKey}`, requestBody);

        setSnack({
          open: true,
          message: `The incident is created successfully ${newbusinessKey}`,
          severity: "success",
        });
        
        navigate("/dashboard");
      } 
      else { setActiveStep((prevActiveStep) => prevActiveStep + 1); }
    } catch (error) {
      console.error("Error processing step:", error);
      setSnack({ message: "An error occurred while processing the step.", severity: "error",});}
  };

  const handleBack = () => {
    if (activeStep === 0) {
      const userName = localStorage.getItem('userName');
      const userEmail = localStorage.getItem('userEmail');
      const userRole = localStorage.getItem('userRole');
      localStorage.clear();
      if (userName) localStorage.setItem('userName', userName);
      if (userEmail) localStorage.setItem('userEmail', userEmail);
      if (userRole) localStorage.setItem('userRole', userRole);
      navigate(-1);
    } else {
      setActiveStep((prevActiveStep) => prevActiveStep - 1);
    }
  };

  const handleSave = () => {};

  return (
    <Box sx={{ width: "auto", height: "95%", m: 2, mt: 2, px: 10, paddingLeft: 15 }}>
      <Stepper activeStep={activeStep} sx={{ px: 50, mt: 2, mb: 2 }}>
        {steps.map((label, index) => {
          const stepProps = {};
          const labelProps = {};
          if (isStepOptional(index)) {
            labelProps.optional = <Typography variant="caption"></Typography>;
          }
          return (
            <CustomStep key={label} {...stepProps}>
              <CustomStepLabel {...labelProps}>{label}</CustomStepLabel>
            </CustomStep>
          );
        })}
      </Stepper>
      <React.Fragment>
        <Box sx={{ pt: 0, px: 2 }}>
          {activeStep === 0 && <IncidentDetails businessid={businessid} />}
          {activeStep === 1 && <PatientDetails businessid={businessid} />}
          {activeStep === 2 && <LocationUpdate businessid={businessid} />}
          {/* {activeStep === 3 && <PatientAssessment businessid={businessid} />} */}
        </Box>
        <Grid container justifyContent="space-between" sx={{ pt: 4, px: 5 }}>
          <Grid item xs={6}>
            <SecondaryButton color="inherit" onClick={handleBack}> Back </SecondaryButton>
          </Grid>
          <Grid item xs={6} container columnGap={2} justifyContent="flex-end" sx={{ paddingRight: "50px" }}>
            <SecondaryButton onClick={handleSave}> Save </SecondaryButton>
            <StyledButton onClick={handleNext}> {activeStep === steps.length - 1 ? "Submit" : "Next"}</StyledButton>
          </Grid>
        </Grid>
      </React.Fragment>
    </Box>
  );
}
