import React from 'react';
import { Line } from 'react-chartjs-2';
import { Chart as ChartJS, LineElement, CategoryScale, LinearScale, PointElement, Tooltip, Legend, } from 'chart.js';
import {Paper, Typography} from "@mui/material";

ChartJS.register(LineElement, CategoryScale, LinearScale, PointElement, Tooltip, Legend);

const IncidentGraph = () => {
    // Generate random incident data for the last 12 months
    const months = Array.from({ length: 12 }, (v, i) => {
        const date = new Date();
        date.setMonth(date.getMonth() - i);
        return date.toLocaleString('default', { month: 'short' });
    }).reverse();

    // Randomly generate incident counts
    const incidentsPerMonth = months.map(() => Math.floor(Math.random() * 10));

    const data = {
        labels: months,
        datasets: [
            {
                label: 'Incidents Created',
                data: incidentsPerMonth,
                borderColor: 'rgba(255, 99, 132, 1)', // Red
                backgroundColor: 'rgba(255, 99, 132, 0.2)',
                fill: true,
            },
            {
                label: 'Incidents Resolved',
                data: months.map(() => Math.floor(Math.random() * 10)), // Random data for illustration
                borderColor: 'rgba(54, 162, 235, 1)', // Blue
                backgroundColor: 'rgba(54, 162, 235, 0.2)',
                fill: true,
            },
            {
                label: 'Incidents Pending',
                data: months.map(() => Math.floor(Math.random() * 10)), // Random data for illustration
                borderColor: 'rgba(75, 192, 192, 1)', // Teal
                backgroundColor: 'rgba(75, 192, 192, 0.2)',
                fill: true,
            },
            
        ],
    };

    return (
        <Paper sx={{ width: '600px', height: '400px', padding: '20px' }}> {/* Add padding here */}
            <Typography variant="h6" sx={{ mb: 2, fontWeight: 'bold' }}>
                Last One Year Incidents
            </Typography>
            <div style={{ width: '100%', height: '100%', paddingTop: '10px' }}> {/* Allow space for the title */}
                <Line data={data} />
            </div>
        </Paper>
    );
    
};

export default IncidentGraph;
