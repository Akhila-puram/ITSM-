import React from "react";
import { Paper, Grid, Avatar, Typography, Box } from "@mui/material";
import DashboardTable from "./dashboardtable";



const Home = () => {
  return (
    <Box sx={{ width: "auto", height:'auto', m: 1, mt: 1, ml:2, p:2.5, }}>
           
      <DashboardTable/>
    </Box>
  );
};

export default Home;
