
import React, { useState, useEffect } from 'react';
import { Button, Paper, Table, TableBody, TableCell, TableContainer, TableHead, TableRow, Typography, TablePagination, Box } from '@mui/material';
import { useNavigate, useParams } from 'react-router-dom';
import axios from 'axios';
import IncidentGraph from "./DashboardGraph";
import DashboardPiechart from "./DashboardPiechart";

export default function IncidentReport({ menuItems }) {
    const [page, setPage] = useState(0);
    const [rowsPerPage, setRowsPerPage] = useState(10);
    const [incidents, setIncidents] = useState([]);
    const navigate = useNavigate();
    const [userRole, setUserRole] = useState('');
    const [selectedStatus, setSelectedStatus] = useState(null);
    const { caseId } = useParams();
    

    useEffect(() => {
        const userRole = localStorage.getItem('userRole');
        setUserRole(userRole || '');
    }, []);

    useEffect(() => {
        const fetchIncidents = async () => {
            try {
                const userEmail = localStorage.getItem('userEmail');
                const userRole = localStorage.getItem('userRole');
                const userName = localStorage.getItem('userName');
                localStorage.clear();
                if (userName) localStorage.setItem('userName', userName);
                if (userEmail) localStorage.setItem('userEmail', userEmail);
                if (userRole) localStorage.setItem('userRole', userRole);
                if (!userEmail) {
                    console.error('No email found in local storage');
                    return;
                }

                let url;
                if (userRole === 'investigationteam') {
                    url = `${import.meta.env.VITE_BASE_URL}/getmyincidentcases?role=${encodeURIComponent(userRole)}&userId=${encodeURIComponent(userEmail)}`;
                } else if (userRole === 'Operation Incident Manager' || userRole === 'Patient Safety Incident Manager') {
                    url = `${import.meta.env.VITE_BASE_URL}/getmyincidentcases?role=${encodeURIComponent(userRole)}&userId=${encodeURIComponent(userEmail)}`;
                } else {
                    url = `${import.meta.env.VITE_BASE_URL}/getmyincidentcases?role=${encodeURIComponent(userRole)}&userId=${encodeURIComponent(userEmail)}`;
                }

                const response = await axios.get(url);
                setIncidents(response.data);

            } catch (error) {
                console.error('Error fetching incidents:', error);
            }
        };

        fetchIncidents();
    }, []);

    const handleChangePage = (event, newPage) => {
        setPage(newPage);
    };

    const handleChangeRowsPerPage = (event) => {
        setRowsPerPage(parseInt(event.target.value, 10));
        setPage(0);
    };

    const handleReportIncident = async () => {
        try {
            const response = await fetch(`${import.meta.env.VITE_BASE_URL}/processIncidentCase`, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify({
                    incidentName: "Sample Incident",
                    description: "Detailed description of the incident",
                }),
            });

            if (response.ok) {
                const data = await response.json();
                const businessid = data.processDefinitionKey;
                const businessKey = data.businessKey;
                const newbusinessKey = businessKey.replace('INC', '');
                localStorage.setItem('businessid', businessid);
                localStorage.setItem("businessKey", businessKey);
                localStorage.setItem("newbusinessKey", newbusinessKey);

                navigate('/StepperCreate', { state: { businessid } });
            } else {
                console.error('Error reporting incident:', response.statusText);
            }
        } catch (error) {
            console.error('Error reporting incident:', error);
        }
    };

    const handleCaseClick = (caseId, status) => {
        setSelectedStatus(status); 
        if (userRole === 'investigationteam') {
            navigate(`/Instructor/${caseId}`);
        } else if (userRole === 'patientsafetymanager') {
            navigate(`/manager/${caseId}`);
        }
        else if (userRole === "nurse" || "doctor") {
            navigate(`/Instructor/${caseId}`);
        }
    };

    const shouldShowReportIncidentButton = userRole === 'doctor' || userRole === 'nurse';

    return (
        <Box mb={2} sx={{ paddingLeft: '40px', width: "auto", height: "auto" }}>
            <Box mb={2} paddingTop={2}>
                <div style={{ display: 'flex', flexDirection: 'column', flex: 1, marginLeft: '10px', mt: 2 }}>
                    <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', paddingBottom: '10px' }}>
                        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', paddingBottom: '10px' }}>
                            <div style={{ marginRight: '40px' }}>
                                <IncidentGraph />
                            </div>
                            <div style={{ width: '700px' }}  >
                                <DashboardPiechart padd={20} />
                            </div>
                        </div>
                        {shouldShowReportIncidentButton && (
                            <Button
                                variant="contained"
                                sx={{
                                    backgroundColor: '#145A7B',
                                    padding: "10px",
                                    color: 'white',
                                    '&:hover': { backgroundColor: '#4D99BD' },
                                    marginLeft: '20px'
                                }}
                                onClick={handleReportIncident}
                            >
                                Report Incident
                            </Button>
                        )}
                    </div>
                </div>
            </Box>

            <Paper mt={2} mb={2} sx={{ padding: "20px", width: "auto", }}>
                <Typography variant="h6" sx={{ flexGrow: 1, paddingBottom: "20px", fontWeight: 'bold' }}>
                    Incidents Created
                </Typography>
                <TableContainer sx={{ padding: '0px', }}>
                    <Table>
                        <TableHead>
                            <TableRow sx={{ backgroundColor: '#145A7B' }}>
                                <TableCell sx={{ color: 'white', fontWeight: 'bold' }}>Case ID</TableCell>
                                <TableCell sx={{ color: 'white', fontWeight: 'bold' }}>Creation Time</TableCell>
                                <TableCell sx={{ color: 'white', fontWeight: 'bold' }}>Reported By</TableCell>
                                <TableCell sx={{ color: 'white', fontWeight: 'bold' }}>Case Status</TableCell>
                                <TableCell sx={{ color: 'white', fontWeight: 'bold' }}>Incident Manager</TableCell>
                                {(userRole === 'nurse' || userRole === 'doctor' ) && (
                                    <TableCell sx={{ color: 'white', fontWeight: 'bold' }}>Actions</TableCell>
                                )}
                            </TableRow>
                        </TableHead>
                        <TableBody>
                            {incidents.slice(page * rowsPerPage, page * rowsPerPage + rowsPerPage).map((incident) => (
                                <TableRow
                                    key={incident.caseId}
                                    
                                    sx={{ backgroundColor: 'white', cursor: 'pointer', '&:hover': { backgroundColor: '#f0f0f0', } }} >
                                    <TableCell onClick={() => handleCaseClick(incident.caseId, incident.status)}>{incident.caseId}</TableCell>
                                    <TableCell onClick={() => handleCaseClick(incident.caseId, incident.status)}>{incident.creationTime}</TableCell>
                                    <TableCell onClick={() => handleCaseClick(incident.caseId, incident.status)}>{incident.reportedBy}</TableCell>
                                    <TableCell onClick={() => handleCaseClick(incident.caseId, incident.status)}>{incident.status}</TableCell>
                                    <TableCell onClick={() => handleCaseClick(incident.caseId)}>{incident.incidentManager}</TableCell>
                                    {(userRole === 'nurse' || userRole === 'doctor' ) && (
                                        <TableCell>
                                            <Typography
                                                sx={{ textDecoration: 'underline', color: 'blue', cursor: 'pointer', '&:hover': { color: 'darkblue' } }}
                                                
                                                onClick={() => {
                                                    localStorage.setItem('status', incident.status); // Store status
                                                    navigate(`/assessment/${incident.caseId}`); // Navigate to Assessment
                                                }}
                                            >
                                                {incident.status === 'open' ? 'Initial Assessment' : 'Follow-Up Assessment'}
                                            </Typography>
                                        </TableCell>)}
                                </TableRow>
                            ))}
                        </TableBody>
                    </Table>
                </TableContainer>

                <TablePagination
                    component="div"
                    count={incidents.length}
                    page={page}
                    onPageChange={handleChangePage}
                    rowsPerPage={rowsPerPage}
                    onRowsPerPageChange={handleChangeRowsPerPage}
                    rowsPerPageOptions={[5, 8, 10]}
                    labelRowsPerPage="Records per page"
                />
            </Paper>
        </Box>
    );
}

