
import React from 'react';
import { Pie } from 'react-chartjs-2';
import { Chart, ArcElement, Tooltip, Legend } from 'chart.js';
import {Paper, Typography} from "@mui/material";

// Register necessary components
Chart.register(ArcElement, Tooltip, Legend);

const PieChartComponent = () => {
    // Data for incident types
    const incidentTypeData = {
        labels: ['Operation Safety Incident', 'Patient Safety Incident'],
        datasets: [
            {
                label: 'Incident Types',
                data: [30, 70], // Random values
                backgroundColor: ['#FF6384', '#36A2EB'],
                borderColor: ['#FFFFFF', '#FFFFFF'],
                borderWidth: 2,
            },
        ],
    };

    // Data for incident priorities
    const incidentPriorityData = {
        labels: ['High', 'Medium', 'Low'],
        datasets: [
            {
                label: 'Incident Priorities',
                data: [50, 30, 20], // Random values
                backgroundColor: ['#FFCE56', '#4BC0C0', '#9966FF'],
                borderColor: ['#FFFFFF', '#FFFFFF', '#FFFFFF'],
                borderWidth: 2,
            },
        ],
    };

    return (
        <Paper sx={{ width: '600px', height: '400px', padding: '20px' }}>
        <div style={{ display: 'flex', justifyContent: 'space-around', margin: '20px' }}>
            <div style={{ width: '300px', height: '300px' }}>
                <h3>Incident Priorities</h3>
                <Pie data={incidentPriorityData} />
            </div>
            <div style={{ width: '300px', height: '300px' }}>
                <h3>Incident Types</h3>
                <Pie data={incidentTypeData} />
            </div>
            
        </div>
        </Paper>
    );
};

export default PieChartComponent;
