import React, { useState, useEffect } from "react";
import { TextField, Button, Typography, Box, FormControlLabel,InputAdornment, IconButton,Paper,} from "@mui/material";
import { styled } from "@mui/system";
import Image from "../../assets/BackgroundLogin.png"; 
import Logo from "../../assets/logo_full.png"; 
import { Visibility, VisibilityOff } from "@mui/icons-material";
import { useNavigate } from "react-router-dom";
import CustomCheckbox from "../GlobalComponents/CustomCheckBox";
import credentials from "../json/user.json";

const RootContainer = styled(Box)({
  height: '100vh',
  width: '100vw',
  backgroundImage: `url(${Image})`,
  backgroundSize: 'cover',
  backgroundPosition: 'center',
  display: 'flex',
  justifyContent: 'flex-end',
  alignItems: 'center',
});

const StyledPaper = styled(Paper)({
  width: '22vw',
  height: '50vh',
  padding: '2rem',
  backgroundColor: 'white',
  boxShadow: '10px 20px 20px rgba(0, 0, 0, 0.2)', 
  display: 'flex',
  flexDirection: 'column',
  justifyContent: 'center',
  marginRight: '22rem',
});

const LogoContainer = styled(Box)({
  position: 'absolute',
  top: '1rem',
  left: '1rem',
});

const InputField = styled(TextField)({
  marginBottom: '1rem',
  '& .MuiOutlinedInput-root': {
    borderRadius: '8px',
    backgroundColor: '#FFFFFF',
    '& fieldset': {
      borderColor: '#CCCCCC',
    },
  },
});

const LoginButton = styled(Button)({
  marginTop: '2rem',
  backgroundColor: '#4D99BD',
  color: 'white',
  '&:hover': {
    backgroundColor: '#145A7B',
  },
});

const ForgotPasswordLink = styled(Typography)({
  marginTop: '1rem',
  textDecoration: 'underline',
  color: '#383A3E',
  cursor: 'pointer',
});

const Login = ({ setUser }) => {
  const [showPassword, setShowPassword] = useState(false);
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const navigate = useNavigate();

  const handleClickShowPassword = () => setShowPassword(!showPassword);

  const handleLogin = (event) => {
    event.preventDefault();
    const user = credentials.find(
      (cred) => cred.email === email && cred.password === password
    );
    if (user) {
      setUser(user);
      localStorage.setItem("userEmail", user.email);
      localStorage.setItem("userName", user.name);
      localStorage.setItem("userRole", user.role);
      navigate("/dashboard");
    } else {
      alert("Invalid username or password");
    }
  };

  useEffect(() => {
    localStorage.clear();
  }, []);

  return (
    <RootContainer>
      <LogoContainer>
        <img src={Logo} alt="Logo" width="180px" />
      </LogoContainer>
      <StyledPaper>
        <Typography mt={2} variant="h4" mb={2} align="center" sx={{ fontWeight: "bold", color:"#4D99BD" }}>
          Welcome Back
        </Typography>
        <Typography variant="subtitle1" sx={{ marginTop: '2rem' }}>
          Username
        </Typography>
        <InputField variant="outlined" fullWidth value={email} onChange={(e) => setEmail(e.target.value)} />
        <Typography variant="subtitle1">Password</Typography>
        <InputField type={showPassword ? "text" : "password"} fullWidth value={password} onChange={(e) => setPassword(e.target.value)}
          InputProps={{ endAdornment: ( <InputAdornment position="end">
                <IconButton onClick={handleClickShowPassword}>
                  {showPassword ? <Visibility /> : <VisibilityOff />}
                </IconButton>
              </InputAdornment>
            ),}}
        />
        <FormControlLabel  control={<CustomCheckbox />}
          label={<Typography  sx={{ fontSize: "16px", fontWeight: "bold", }}>Remember me</Typography>} />
        <LoginButton mt={2} variant="contained" fullWidth onClick={handleLogin}>
          Login
        </LoginButton>
        <ForgotPasswordLink align="center">
          Forgot Password?
        </ForgotPasswordLink>
      </StyledPaper>
    </RootContainer>
  );
};

export default Login;
