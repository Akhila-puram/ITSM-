import React, { useEffect, useState } from 'react';
import { Box, Button, Grid, TextField, FormControl, Select, MenuItem, Paper, Typography } from '@mui/material';
import { useNavigate } from 'react-router-dom';

const PatientAssessment = () => {
    const navigate = useNavigate();
    const [fields, setFields] = useState([]);

    // Fetch form metadata from API
    useEffect(() => {
        fetch('http://localhost:8989/getForms?formId=IncidentCreation&processDefinitionKey=2251799816653812')
            .then((response) => response.json())
            .then((data) => {
                const schema = JSON.parse(data.schema);
                setFields(schema.components); // Save the components array
            })
            .catch((error) => console.error('Error fetching form data:', error));
    }, []);

    // Function to render individual field based on type
    const renderField = (field) => {
        switch (field.type) {
            case 'textfield':
                return (
                    <Grid item xs={12} sm={6} md={4} mt={2} key={field.id}>
                        <Typography>{field.label}</Typography>
                        <TextField
                            fullWidth
                            type="text"
                            sx={{ height: '30px', mb: 1 }}
                        />
                    </Grid>
                );
            case 'datetime':
                return (
                    <Grid item xs={12} sm={6} md={4} mt={2} key={field.id}>
                        <Typography>{field.dateLabel || field.label}</Typography>
                        <TextField
                            fullWidth
                            type={field.subtype === 'date' ? 'date' : 'time'}
                            sx={{ height: '30px', mb: 1 }}
                        />
                    </Grid>
                );
            case 'select':
                return (
                    <Grid item xs={12} sm={6} md={4} mt={2} key={field.id}>
                        <Typography>{field.label}</Typography>
                        <FormControl fullWidth>
                            <Select defaultValue="">
                                {field.values.map((option) => (
                                    <MenuItem key={option.value} value={option.value}>
                                        {option.label}
                                    </MenuItem>
                                ))}
                            </Select>
                        </FormControl>
                    </Grid>
                );
            case 'button':
                return (
                    <Grid item xs={12} mt={2} key={field.id}>
                        <Button variant="contained" color="primary">
                            {field.label}
                        </Button>
                    </Grid>
                );
            default:
                return null;
        }
    };

    return (
        <Box sx={{ display: 'flex', justifyContent: 'center', alignItems: 'center', marginRight: 6 }}>
            <Paper elevation={2} sx={{ padding: '30px', backgroundColor: 'white', borderRadius: '8px', overflow: 'auto' }}>
                <Typography variant="h4" sx={{ flexGrow: 1, marginLeft: '0px', paddingBottom: "20px" }}>
                    Incident Creation
                </Typography>
                <Grid container spacing={3}>
                    {/* Dynamically render fields */}
                    {fields.map((field) => renderField(field))}
                </Grid>
            </Paper>
        </Box>
    );
};

export default PatientAssessment;
