
import React, { useEffect, useState } from 'react';
import { Box, Grid, TextField, FormControl, Select, MenuItem, Paper, Typography, CircularProgress } from '@mui/material';
import { useNavigate } from 'react-router-dom';

const LocationUpdate = () => {
    const navigate = useNavigate();
    const [fields, setFields] = useState([]);
    const [incidentType, setIncidentType] = useState('');
    const [incidentCategory, setIncidentCategory] = useState('');
    const [incidentSubCategory, setIncidentSubCategory] = useState('');
    const [incidentCategories, setIncidentCategories] = useState([]);
    const [incidentSubCategories, setIncidentSubCategories] = useState([]);
    const [selectedValues, setSelectedValues] = useState({});
    const [businessid, setBusinessid] = useState(""); 
    const [loading, setLoading] = useState(true);


    useEffect(() => {
        const fetchedBusinessid = localStorage.getItem('businessid') || ""; 

        setBusinessid(fetchedBusinessid); 

        if (fetchedBusinessid) { 
            setLoading(true); 
            console.log("Fetching form data with business key:", fetchedBusinessid);
            fetch(`http://localhost:8989/getForms?formId=LocationDetails&processDefinitionKey=${fetchedBusinessid}`)
                .then((response) => {
                    if (!response.ok) {
                        throw new Error('Network response was not ok');
                    }
                    return response.json();
                })
                .then((data) => {
                    const schema = JSON.parse(data.schema);
                    setFields(schema.components);
                    setLoading(false);
                })
                .catch((error) => console.error('Error fetching form data:', error));
        }
    }, []);

    const handleFieldChange = (label, value) => {
        localStorage.setItem(label, value);
    };

    

    const renderField = (field) => {
        switch (field.type) {
            case 'textfield':
                return (
                    <Grid item xs={12} sm={6} md={4} mt={2} key={field.id}>
                        <Typography>{field.label}</Typography>
                        <TextField
                            fullWidth
                            type="text"
                            defaultValue={localStorage.getItem(field.label) || ''}
                            sx={{ height: '30px', mb: 1 }}
                            onChange={(e) => handleFieldChange(field.label, e.target.value)}
                        />
                    </Grid>
                );
            case 'datetime':
                return (
                    <Grid item xs={12} sm={6} md={4} mt={2} key={field.id}>
                        <Typography>{field.dateLabel || field.label}</Typography>
                        <TextField
                            fullWidth
                            type={field.subtype === 'date' ? 'date' : 'time'}
                            defaultValue={localStorage.getItem(field.label) || ''}
                            sx={{ height: '30px', mb: 1 }}
                            onChange={(e) => handleFieldChange(field.label, e.target.value)}
                        />
                    </Grid>
                );
                
                case 'textarea':
                return (
                    <Grid item xs={12} sm={6} md={6} mt={2} key={field.id}>
                        <Typography>{field.label}</Typography>
                        <TextField
                            fullWidth
                            multiline
                            rows={2}
                            defaultValue={localStorage.getItem(field.label) || ''}
                            sx={{ mb: 1 }}
                            onChange={(e) => handleFieldChange(field.label, e.target.value)}
                        />
                    </Grid>
                );
            default:
                return null;
        }
    };
    if (loading) {
        return (
            <Box sx={{ display: 'flex', justifyContent: 'center', alignItems: 'center', height: '100vh' }}>
                <CircularProgress color="inherit" size="4rem"/>
            </Box>
        );
    }

    return (
        <Box sx={{ justifyContent: 'center', alignItems: 'center', marginRight: 6 }}>
            <Paper elevation={2} sx={{ padding: '30px', backgroundColor: 'white', borderRadius: '8px', overflow: 'auto' }}>
                <Typography variant="h4" sx={{ flexGrow: 1, marginLeft: '0px', paddingBottom: '20px' }}>
                    Location Update
                </Typography>
                <Grid container spacing={3}>
                    {fields.map((field) => renderField(field))}
                </Grid>
            </Paper>
        </Box>
    );
};

export default LocationUpdate;
