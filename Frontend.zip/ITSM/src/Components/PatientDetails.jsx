import React, { useEffect, useState } from 'react';
import { Box, Grid, TextField, FormControl, Select, Radio, MenuItem, Paper, Typography, FormGroup, FormControlLabel, CircularProgress } from '@mui/material';
import { useNavigate } from 'react-router-dom';
import { color } from 'chart.js/helpers';

const PatientDetails = () => {
    const navigate = useNavigate();
    const [fields, setFields] = useState([]);
    const [businessid, setBusinessid] = useState("");
    const [radioValues, setRadioValues] = useState({}); 
    const [loading, setLoading] = useState(true);

    useEffect(() => {
        const fetchedBusinessid = localStorage.getItem('businessid') || "";

        setBusinessid(fetchedBusinessid);

        if (fetchedBusinessid) {
            setLoading(true);
            fetch(`http://localhost:8989/getForms?formId=PatientDetails&processDefinitionKey=${fetchedBusinessid}`)
                .then((response) => response.json())
                .then((data) => {
                    const schema = JSON.parse(data.schema);
                    setFields(schema.components);
                    setLoading(false);

                    // Initialize radio values from localStorage
                    const initialRadioValues = schema.components
                        .filter(field => field.type === 'radio')
                        .reduce((acc, field) => {
                            acc[field.label] = localStorage.getItem(field.label) || '';
                            return acc;
                        }, {});
                    setRadioValues(initialRadioValues);
                })
                .catch((error) => console.error('Error fetching form data:', error));
        }
    }, []);

    const handleFieldChange = (label, value) => {
        localStorage.setItem(label, value);

        if (fields.find(field => field.label === label)?.type === 'radio') {
            setRadioValues(prev => ({
                ...prev,
                [label]: value
            }));
        }
    };

    const renderField = (field) => {
        switch (field.type) {
            case 'textfield':
                return (
                    <Grid item xs={12} sm={6} md={4} mt={2} key={field.id}>
                        <Typography>{field.label}</Typography>
                        <TextField
                            fullWidth
                            type="text"
                            defaultValue={localStorage.getItem(field.label) || ''}
                            sx={{ height: '30px', mb: 1 }}
                            onChange={(e) => handleFieldChange(field.label, e.target.value)}
                        />
                    </Grid>
                );
            case 'datetime':
                return (
                    <Grid item xs={12} sm={6} md={4} mt={2} key={field.id}>
                        <Typography>{field.dateLabel || field.label}</Typography>
                        <TextField
                            fullWidth
                            type={field.subtype === 'date' ? 'date' : 'time'}
                            defaultValue={localStorage.getItem(field.label) || ''}
                            sx={{ height: '30px', mb: 1 }}
                            onChange={(e) => handleFieldChange(field.label, e.target.value)}
                        />
                    </Grid>
                );
            case 'radio':
                return (
                    <Grid item xs={12} sm={6} md={4} mt={2} key={field.id}>
                        <Typography>{field.label}</Typography>
                        <FormControl component="fieldset">
                            <FormGroup row>
                                {field.values && field.values.map((option) => (
                                    <FormControlLabel
                                        key={option.value}
                                        control={
                                            <Radio
                                                value={option.value}
                                                checked={radioValues[field.label] === option.value } 
                                                onChange={(e) => handleFieldChange(field.label, e.target.value)}
                                                sx={{ '&.Mui-checked': { color: '#145A7B', }, }}
                                            />
                                        }
                                        label={option.label}
                                    />
                                ))}
                            </FormGroup>
                        </FormControl>
                    </Grid>
                );
            case 'select':
                return (
                    <Grid item xs={12} sm={6} md={4} mt={2} key={field.id}>
                        <Typography>{field.label}</Typography>
                        <Select
                            fullWidth
                            value={localStorage.getItem(field.label) || ''}
                            onChange={(e) => handleFieldChange(field.label, e.target.value)}
                            sx={{ height: '30px', mb: 1 }}
                        >
                            {field.values && field.values.map((option) => (
                                <MenuItem key={option.value} value={option.value}>
                                    {option.label}
                                </MenuItem>
                            ))}
                        </Select>
                    </Grid>
                );
            case 'textarea':
                return (
                    <Grid item xs={12} sm={6} md={6} mt={2} key={field.id}>
                        <Typography>{field.label}</Typography>
                        <TextField
                            fullWidth
                            multiline
                            rows={2}
                            defaultValue={localStorage.getItem(field.label) || ''}
                            sx={{ mb: 1 }}
                            onChange={(e) => handleFieldChange(field.label, e.target.value)}
                        />
                    </Grid>
                );
            default:
                return null;
        }
    };
    if (loading) {
        return (
            <Box sx={{ display: 'flex', justifyContent: 'center', alignItems: 'center', height: '100vh' }}>
                <CircularProgress color="#145A7B" size="4rem"/>
            </Box>
        );
    }

    return (
        <Box sx={{ justifyContent: 'center', alignItems: 'center', marginRight: 6 }}>
            <Paper elevation={2} sx={{ padding: '30px', backgroundColor: 'white', borderRadius: '8px', overflow: 'auto' }}>
                <Typography variant="h4" sx={{ flexGrow: 1, marginLeft: '0px', paddingBottom: '20px' }}>
                    Patient Details
                </Typography>
                <Grid container spacing={3}>
                    {fields.map((field) => renderField(field))}
                </Grid>
            </Paper>
        </Box>
    );
};

export default PatientDetails;
