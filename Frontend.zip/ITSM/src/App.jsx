import { useState } from "react";
import "./App.css";
import Login from "./Components/Login/Login";
import { CssBaseline, ThemeProvider } from "@mui/material";
import createTheme from '@mui/material/styles/createTheme';
import { SnackProvider } from "./Components/GlobalComponents/SnackProvider";
import { Navigate, Route, Routes, BrowserRouter as Router } from "react-router-dom"; 
import Layout from "./Components/GlobalComponents/Layout";
import Dashboard from "./Components/dashboard/dashboard";
import Instructor from "./Components/Instructor";
import Manager from "./Components/Manager";
import StepperCreate from "./Components/StepperCreate";
import PatientAssessment from "./Components/PatientAssessment";


const defaultTheme = createTheme();

function App() {
  const [user, setUser] = useState(null); 

  return (
    <ThemeProvider theme={defaultTheme}>
      <Router> 
        <div className="App">
          {!localStorage.getItem("userEmail") ? (
            <Login setUser={setUser} />
          ) : (
            <>
              <SnackProvider>
                <Routes>
                  <Route element={<Layout user={user} setUser={setUser} />}>
                  <Route index element={<Navigate to="/dashboard" />} />
                  <Route path="dashboard" element={<Dashboard />} />
                  <Route path="/assessment/:caseId" element={<PatientAssessment />} />
                  <Route path="StepperCreate" element={<StepperCreate />} />
                  <Route path="/Instructor/:caseId" element={<Instructor />} />
                  <Route path="/Manager/:caseId" element={<Manager />} />
                  </Route>
                </Routes>
              </SnackProvider>
            </>
          )}
        </div>
      </Router>
    </ThemeProvider>
  );
}

export default App;


